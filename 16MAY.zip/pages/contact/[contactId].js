import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import Image from 'next/image';
import ProfileIcon from '../../public/assets/images/icons/ProfileIcon.svg';
import More from '../../public/assets/images/icons/More.svg';
import axiosInstance from '@/services/api';

const ContactDetailsPage = () => {
    const router = useRouter();
    const { contactId } = router.query;
    console.log(contactId, 'ediidcontactId');

    const [contactDetails, setContactDetails] = useState(null);
    const [loading, setLoading] = useState(true); // Track loading state

    useEffect(() => {
        const fetchContactDetails = async () => {
            try {
                const response = await axiosInstance.get(`/contact_details/contactuser/${contactId}`);
                const ContactuserDetails = response.data.contact;
                setContactDetails(ContactuserDetails);
            } catch (error) {
                console.error('Error fetching contact details:', error);
            } finally {
                setLoading(false); // Update loading state regardless of success or failure
            }
        };

        // Fetch data only if contactId exists
        if (contactId) {
            fetchContactDetails();
        }
    }, [contactId]);

    return (
        <div className="panel flex min-h-screen w-full flex-col ">
            {loading ? ( // Check loading state
                <p>Loading...</p> // Render a loading message while data is being fetched
            ) : contactDetails ? ( // Check if contactDetails is available
                <div>
                    <div className="flex h-[80px] w-full items-center justify-between border-b-2 bg-white p-2">
                        <div className="  flex  items-center justify-center  ">
                            <Image src={ProfileIcon} width={50} height={50} alt="profileicon" className="ml-2" />
                            <span className="ml-2 text-2xl font-medium">{contactDetails.fullname}</span>
                        </div>
                        <div>
                            <Image src={More} width={4} height={4} alt="more" />
                        </div>
                    </div>
                    <div className=" w-full border-red-500 px-6 py-8">
                        <div className="grid w-full grid-cols-3 gap-8">
                            <div className="h-28 max-w-full rounded-md bg-[#f1f2f3] px-4 py-9 sm:px-3 sm:py-5">
                                <div className="flex flex-col space-y-5 px-2 py-2">
                                    <span>Name</span>
                                    <span>{contactDetails.fullname}</span>
                                </div>
                            </div>

                            <div className="h-28 max-w-full rounded-md bg-[#f1f2f3] px-4 py-9 sm:px-3 sm:py-5">
                                <div className="flex flex-col space-y-5  px-2 py-2 ">
                                    <span>Job Title</span>
                                    <span>{contactDetails.contact_jobtitle}</span>
                                </div>
                            </div>

                            <div className="h-28 max-w-full rounded-md bg-[#f1f2f3] px-4 py-9 sm:px-3 sm:py-5">
                                <div className="flex flex-col space-y-5  px-2 py-2 ">
                                    <span> Company Name </span>
                                    <span> {contactDetails.company}</span>
                                </div>
                            </div>

                            <div className="h-28 max-w-full rounded-md bg-[#f1f2f3] px-4 py-9 sm:px-3 sm:py-5">
                                <div className="flex flex-col space-y-5  px-2 py-2 ">
                                    <span> Email </span>
                                    <span> {contactDetails.contact_email}</span>
                                </div>
                            </div>
                            <div className="h-28 max-w-full rounded-md bg-[#f1f2f3] px-4 py-9 sm:px-3 sm:py-5">
                                <div className="flex flex-col space-y-5  px-2 py-2 ">
                                    <span> Phone Number </span>
                                    <span> {contactDetails.contact_phonenumber}</span>
                                </div>
                            </div>
                            <div className="h-28 max-w-full rounded-md bg-[#f1f2f3] px-4 py-9 sm:px-3 sm:py-5">
                                <div className="flex flex-col space-y-5  px-2 py-2 ">
                                    <span> Website </span>
                                    <span> {contactDetails.website}</span>
                                </div>
                            </div>
                            {/* Include similar blocks for other contact details */}
                        </div>
                    </div>
                </div>
            ) : (
                <p>Contact details not found.</p> // Render a message if contactDetails is null
            )}
        </div>
    );
};

export default ContactDetailsPage;

// // pages/contact/[id].js
// import { useRouter } from 'next/router';

// import Image from 'next/image';
// import ProfileIcon from '../../public/assets/images/icons/ProfileIcon.svg';
// import More from '../../public/assets/images/icons/More.svg';

// const ContactDetailsPage = () => {
//     // const router = useRouter();
//     // let { id,data, ...contactDetails } = router.query;

//     // console.log(contactDetails);

//     const router = useRouter();
//     const { contactId } = router.query; // Get the user ID from the router query parameter
//     const [contactDetails, setUserData] = useState(null);

//     useEffect(() => {
//         const fetchUserData = async () => {
//             try {
//                 // Fetch user data based on the provided user ID
//                 const response = await axios.get(`http://localhost:3001/api/contact_details/contactuser/${contactId}`);
//                 setUserData(response.data); // Set the fetched user data to state
//             } catch (error) {
//                 console.error('Error fetching user data:', error);
//             }
//         };

//         if (contactId) {
//             fetchUserData(); // Fetch user data when the user ID is available
//         }
//     }, [contactId]);

//     return (
//         <div className="panel flex min-h-screen w-full flex-col ">
//             {/* <h1>Contact Details</h1>
//             <p>Contact ID: {id}</p> */}
//             <div className="flex h-[80px] w-full items-center justify-between border-b-2 bg-white p-2">
//                 <div className="  flex  items-center justify-center  ">
//                     <Image src={ProfileIcon} width={50} height={50} alt="profileicon" className="ml-2"></Image>
//                     <span className="ml-2 text-2xl font-medium">{contactDetails.fullname} </span>
//                 </div>
//                 <div>
//                     <Image src={More} width={4} height={4} alt="more"></Image>
//                 </div>
//             </div>
//             <div className=" w-full border-red-500   px-6 py-8">
//                 <div className="grid w-full grid-cols-3 gap-8  ">
//                     <div className="h-28 max-w-full rounded-md bg-[#f1f2f3] px-4 py-9 sm:px-3 sm:py-5">
//                         <div className="flex flex-col space-y-5  px-2 py-2 ">
//                             <span> Name </span>
//                             <span> {contactDetails.fullname}</span>
//                         </div>
//                     </div>
//                     <div className="h-28 max-w-full rounded-md bg-[#f1f2f3] px-4 py-9 sm:px-3 sm:py-5">
//                         <div className="flex flex-col space-y-5  px-2 py-2 ">
//                             <span> Job title </span>
//                             <span> {contactDetails.contact_jobtitle}</span>
//                         </div>
//                     </div>
//                     <div className="h-28 max-w-full rounded-md bg-[#f1f2f3] px-4 py-9 sm:px-3 sm:py-5">
//                         <div className="flex flex-col space-y-5  px-2 py-2 ">
//                             <span> Company Name </span>
//                             <span> {contactDetails.company}</span>
//                         </div>
//                     </div>
//                     <div className="h-28 max-w-full rounded-md bg-[#f1f2f3] px-4 py-9 sm:px-3 sm:py-5">
//                         <div className="flex flex-col space-y-5  px-2 py-2 ">
//                             <span> Email </span>
//                             <span> {contactDetails.contact_email}</span>
//                         </div>
//                     </div>
//                     <div className="h-28 max-w-full rounded-md bg-[#f1f2f3] px-4 py-9 sm:px-3 sm:py-5">
//                         <div className="flex flex-col space-y-5  px-2 py-2 ">
//                             <span> Phone Number </span>
//                             <span> {contactDetails.contact_phonenumber}</span>
//                         </div>
//                     </div>
//                     <div className="h-28 max-w-full rounded-md bg-[#f1f2f3] px-4 py-9 sm:px-3 sm:py-5">
//                         <div className="flex flex-col space-y-5  px-2 py-2 ">
//                             <span> Website </span>
//                             <span> {contactDetails.website}</span>
//                         </div>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default ContactDetailsPage;
