import Link from 'next/link';
import { useEffect, useState } from 'react';
import { setPageTitle } from '../store/themeConfigSlice';
import { useDispatch } from 'react-redux';
import IconUser from '@/components/Icon/IconUser';
import IconPhone from '@/components/Icon/IconPhone';
import ResetModel from './ResetModel';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import axiosInstance from '@/services/api';
import router from 'next/dist/client/router';
const Setting = () => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [currentModalContentId, setCurrentModalContentId] = useState(null);
    const [email, setEmail] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const openModal = (contentId) => {
        setCurrentModalContentId(contentId);
        setIsModalOpen(true);
    };
    const closeModal = () => {
        setIsModalOpen(false);
        setCurrentModalContentId(null);
    };
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(setPageTitle('Account Setting'));
    });
    const [tabs, setTabs] = useState<string>('general');
    const toggleTabs = (name: string) => {
        setTabs(name);
    };
    const MySwal = withReactContent(Swal);

    const showToast = () => {
        MySwal.fire({
            title: 'Updated successfully',
            toast: true,
            position: 'top',
            showConfirmButton: false,
            timer: 3000,
            background: '#4CAF50',
            showCloseButton: true,
        });
    };

    useEffect(() => {
        fetchUserProfile(); // Fetch user profile data on component mount
    }, []); // Empty dependency array to run the effect only once

    const fetchUserProfile = async () => {
        try {
            setIsLoading(true);
            const userId = localStorage.getItem('userId');
            if (!userId) {
                throw new Error('User ID not found in localStorage');
            }
            const auth = localStorage.getItem('token');


            if (!auth || auth === "null") {
                // Display error message
                console.error('Token not found in localStorage');
                // Redirect to login page
                router.push('/Login');
                return;
            }

            const config = {
                headers: {
                    'Authorization': `Bearer ${auth}`, // Set the authorization header properly
                },
            };
            const response = await axiosInstance.get(`/getUserData/useremail/${userId}`,config);
            const { data } = response.data;
            setEmail(data.email); // Assuming email is a field in the user profile data
            setIsLoading(false);
        } catch (error) {
            console.error('Error fetching user profile:', error);
            setIsLoading(false);
        }
    };

    return (
        <div>
            <div className="pt-5">
                <div className="mb-5 flex items-center justify-between">
                    <h5 className="text-lg font-semibold dark:text-white-light">Settings</h5>
                </div>
                <div>
                    <ul className="mb-5 overflow-y-auto whitespace-nowrap border-b border-[#EBEDF2] font-semibold dark:border-[#191E3A] sm:flex">
                        <li className="inline-block">
                            <button
                                onClick={() => toggleTabs('general')}
                                className={`flex gap-2 border-b border-transparent p-4 hover:border-primary hover:text-primary ${tabs === 'general' ? '!border-primary text-primary' : ''}`}
                            >
                                General
                            </button>
                        </li>
                    </ul>
                </div>
                {tabs === 'general' ? (
                    <div className="px-5">
                        <form className="mb-5 rounded-md border border-[#EBEDF2] bg-white p-4 dark:border-[#191E3A] dark:bg-black">
                            <div className="flex justify-between">
                                <div className="mb-5 flex w-[300px]  items-center justify-start ">
                                    <h1 className="text-2xl font-semibold tracking-wide">Account Setting</h1>
                                </div>
                                <div className="panel flex  w-[600px] flex-col">
                                    <div className="mb-4">
                                        <label htmlFor="web">Profile Url </label>
                                        <input id="web" type="text" placeholder="Enter URL" className="form-input" />
                                    </div>
                                    <div className="mb-4">
                                        <label htmlFor="email">Email</label>

                                        <input
                                            id="email"
                                            type="email"
                                            style={{ cursor: 'none', pointerEvents: 'none' }}
                                            placeholder="Jimmy@gmail.com"
                                            defaultValue={email}
                                            className="disable-cursor-pointer form-input"
                                        />
                                    </div>
                                </div>
                            </div>
                        </form>

                        <div>
                            <form className=" flex h-[250px] w-full items-center justify-between rounded-md border border-[#EBEDF2] bg-white p-4 ">
                                <h6 className="mb-5 w-[200px] text-2xl  font-semibold tracking-wide">Account Security</h6>
                                <div className="panel flex w-[600px] flex-col items-start p-3 ">
                                    <div className="flex flex-col ">
                                        <span className=" m-2 cursor-pointer font-normal" onClick={() => openModal('content1')}>
                                            Reset Password
                                        </span>
                                        <span className="m-2 cursor-pointer font-normal" onClick={() => openModal('content2')}>
                                            Delete Account
                                        </span>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div className="mt-4 flex items-center justify-end gap-5 ">
                            <button type="button" className="underline underline-offset-4">
                                Cancel
                            </button>
                            <button type="button" className="btn btn-primary  h-[40px] w-[130px]" onClick={showToast}>
                                Update
                            </button>
                        </div>
                    </div>
                ) : (
                    ''
                )}
            </div>
            <ResetModel isOpen={isModalOpen} onClose={closeModal} modalContentId={currentModalContentId}></ResetModel>
        </div>
    );
};
export default Setting;
