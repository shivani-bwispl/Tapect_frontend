import React from 'react';
import { useState } from 'react';

const Notes = ({ formData, onFormChange }) => {
    const [remainingChars, setRemainingChars] = useState(250);
    const maxChars = 250;
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        if (value.length <= maxChars) {
            onFormChange({
                ...formData,
                [name]: value,
            });
            setRemainingChars(maxChars - value.length);
        }
        if (value.length === 250) {
            // Display alert when character count reaches 250
            alert('Maximum character limit reached (250 characters)');
        }
    };
    return (
        <>
            <div className="px-3">
                <label> Bio</label>
                <textarea
                    className=" h-[80px] w-full resize-none whitespace-normal border  border-white-light p-2 focus:outline-0"
                    name="Bio"
                    onChange={handleInputChange}
                    value={formData.Bio}
                ></textarea>
                {formData.Bio.trim().length > 0 && <p className="text-right text-primary ">{remainingChars} characters remaining</p>}
            </div>

            <div className="mt-4 flex justify-end">
                <button type="button" className="mr-10 underline underline-offset-4">
                    Cancel
                </button>

                <button type="button" className="btn btn-primary mr-5 h-[40px] w-[130px]">
                    Update
                </button>
            </div>
        </>
    );
};

export default Notes;
