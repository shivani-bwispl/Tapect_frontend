import React, { useState, useEffect } from 'react';
import { useImageContext } from '../components/ImageContext';
import Tippy from '@tippyjs/react';
import 'tippy.js/dist/tippy.css';
import Image from 'next/image';
import info_icon from '../public/assets/images/icons/info_icon.svg';
import axios from 'axios';

const FileUpload = () => {
    const [users, setUsers] = useState([]);
    const { coverImage, setCoverImage, profileImage, setProfileImage, logoImage, setLogoImage }: any = useImageContext();

    const defaultCoverImage = '/assets/images/icons/cover_default.png';
    const defaultProfileImage = '/assets/images/icons/profileImg_default.png';
    const defaultLogoImage = '/assets/images/icons/logo_default.png';

    const handleImageCover = async ({ event, setImageFunction, defaultImage }: any) => {
        try {
            const file = event.target.files[0];
            event.preventDefault();
            const formData = new FormData();
            const userId = localStorage.getItem('user');
            formData.append('coverImage', file);
            formData.append('user_id', userId || '');

            // Use Axios for the HTTP request
            // const response = await axios.post('http://localhost:3000/api/profileImagesUpload', formData);

            // Validate file type (you may add additional validation)
            if (file && file.type.startsWith('image/')) {
                const fileExtension = file.name.split('.').pop();
                const imageUrl = `${URL.createObjectURL(file)}.${fileExtension}`;

                setImageFunction(imageUrl);

                console.log('imageUrl:', imageUrl);
            } else {
                // Handle invalid file type (optional)
                setImageFunction(defaultImage);
            }
        } catch (error) {
            console.error('Error handling image cover:', error);
            // Handle the error appropriately
        }
    };

    const handleImageProfile = async ({ event, setImageFunction, defaultImage }: any) => {
        const file = event.target.files[0];
        event.preventDefault();
        const formData = new FormData();
        const userId = localStorage.getItem('user');
        formData.append('profileImage', file);
        formData.append('user_id', userId || '');
        const response = await fetch('http://localhost:3000/api/profileImagesUpload', {
            method: 'POST',
            body: formData,
        });

        const data = await response.json();
        // Validate file type (you may add additional validation)
        if (file && file.type.startsWith('image/')) {
            const imageUrl = URL.createObjectURL(file);
            setImageFunction(imageUrl);

            // console.log('imageUrl:', imageUrl);
        } else {
            // Handle invalid file type (optional)
            // console.error('Invalid file type. Please upload an image.');
            setImageFunction(defaultImage);
        }
    };
    const handleImageLogo = async (event, setImageFunction, defaultImage) => {
        const file = event.target.files[0];

        event.preventDefault();

        const formData = new FormData();
        const userId = localStorage.getItem('user');
        formData.append('logoImage', file);
        formData.append('user_id', userId || null);
        const response = await fetch('./api/profileImagesUpload', {
            method: 'POST',
            body: formData,
        });

        const data = await response.json();
        // Validate file type (you may add additional validation)
        if (file && file.type.startsWith('image/')) {
            const imageUrl = URL.createObjectURL(file);
            setImageFunction(imageUrl);
            // console.log('imageUrl:', imageUrl);
        } else {
            // Handle invalid file type (optional)
            // console.error('Invalid file type. Please upload an image.');
            setImageFunction(defaultImage);
        }

        // Function to handle "Reset" button click
    };
    const handleResetButtonClick = (setImageFunction, defaultImagePath) => {
        setImageFunction(defaultImagePath);
    };
    // Function to handle button click for each image
    const handleButtonClick = (inputId) => {
        // Trigger the respective file upload input when the button is clicked
        document.getElementById(inputId).click();
    };
    useEffect(() => {
        const value = localStorage.getItem('user');

        console.log(value);
        console.log('test');

        // console.log(isLoggedIn);
        // const fetchUserData = async () => {
        //     try {
        //         const response = await fetch('http://localhost:3000/api/getUserDetails', {
        //             method: 'POST',
        //             headers: {
        //                 'Content-Type': 'application/json', // Specify the content type of the request body
        //             },
        //             body: JSON.stringify({ id: value }),
        //         });

        //         const userData = await response.json();

        //         // Assuming 'data' is the key where your user data is stored in the response
        //         if (userData.data && userData.data.user) {
        //             setUsers([userData.data]);
        //         } else {
        //             console.error('Invalid user data format:', userData);
        //         }
        //     } catch (error) {
        //         console.error('Error fetching user data:', error);
        //     }
        // };

        // // Call the function to fetch user data
        // fetchUserData();
    }, []);

    return (
        <div className=" grid-col-2 grid  p-3 lg:grid-cols-2">
            <div className="flex flex-col items-start justify-center ">
                <div className=" mb-4 flex items-center justify-evenly ">
                    <Tippy content="Popover on top" placement="top">
                        <Image src={info_icon} width={20} height={20} alt="info" />
                    </Tippy>
                    <h3 className="mx-1 text-[13px] font-semibold">Cover</h3>
                </div>
                <div className="relative mb-4  ">
                    {users.map((userData) =>
                        // eslint-disable-next-line react/jsx-key, @next/next/no-img-element
                        userData.userProfiles.coverImage && userData.userProfiles.coverImage.trim() !== '' ? (
                            // eslint-disable-next-line react/jsx-key, @next/next/no-img-element
                            <img src={defaultCoverImage} alt="Preview" width={1600} height={160} className="rounded-md border border-gray-300 object-cover" />
                        ) : (
                            // <img
                            //     // src="./assets/images/coverImages/80009cc719caeb79a78dc659136d5308.jpeg"

                            //     src={`./assets/coverImages/${userData.userProfiles.coverImage}`}
                            //     alt="Preview"
                            //     width={1600}
                            //     height={160}
                            //     className="rounded-md border border-gray-300 object-cover"
                            // />
                            // eslint-disable-next-line react/jsx-key, @next/next/no-img-element
                            <img src={defaultCoverImage} alt="Preview" width={1600} height={160} className="rounded-md border border-gray-300 object-cover" />
                        )
                    )}

                    {/* <img src={coverImage} alt="Preview" width={1600} height={160} className="rounded-md border border-gray-300 object-cover" /> */}
                    <button
                        onClick={() => handleButtonClick('coverImageInput')}
                        className="absolute inset-0 flex h-full w-full items-center justify-center rounded-md bg-black opacity-0 hover:opacity-25"
                    >
                        <span className="text-white">Change Image</span>
                    </button>
                    <input id="coverImageInput" type="file" accept="image/*" className="hidden" onChange={(event) => handleImageCover(event, setCoverImage, defaultCoverImage)} />
                </div>

                {/* Conditionally render the "Reset" button */}

                {coverImage !== defaultCoverImage && (
                    <button onClick={() => handleResetButtonClick(setCoverImage, defaultCoverImage)} className="rounded-md bg-red-500 px-2 py-1 text-white">
                        Reset
                    </button>
                )}
            </div>
            <div className="flex w-full items-center justify-center  gap-4 ">
                <div className=" flex  flex-col items-start justify-center   ">
                    <div className=" mb-4 flex items-center justify-evenly  ">
                        <Tippy content="dimension 200 x 200" placement="top">
                            <Image src={info_icon} width={20} height={20} alt="info" />
                        </Tippy>
                        <h3 className="mx-1 text-[13px] font-semibold">Profile</h3>
                    </div>
                    <div className="relative mb-4">
                        {users.map((userData) =>
                            // eslint-disable-next-line react/jsx-key, @next/next/no-img-element
                            userData.userProfiles.profileImage ? (
                                // eslint-disable-next-line react/jsx-key, @next/next/no-img-element
                                <img
                                    // src="./assets/images/coverImages/80009cc719caeb79a78dc659136d5308.jpeg"
                                    src={`./assets/profileImages/${userData.userProfiles.profileImage}.jpeg`}
                                    alt="Preview"
                                    width={160}
                                    height={160}
                                    className="rounded-md border border-gray-300 object-cover"
                                />
                            ) : (
                                // eslint-disable-next-line react/jsx-key, @next/next/no-img-element
                                <img src={profileImage} width={160} height={160} alt="Preview" className=" h-40 w-40 rounded-[50%] border border-gray-300 object-cover" />
                            )
                        )}
                        {/* <img src={profileImage} width={160} height={160} alt="Preview" className=" h-40 w-40 rounded-[50%] border border-gray-300 object-cover" /> */}
                        <button
                            onClick={() => handleButtonClick('profileImageInput')}
                            className="absolute inset-0 flex h-full w-full items-center justify-center rounded-[50%] bg-black opacity-0 hover:opacity-25"
                        >
                            <span className="text-white">Change Image</span>
                        </button>
                        <input id="profileImageInput" type="file" accept="image/*" className="hidden" onChange={(event) => handleImageProfile(event, setProfileImage, defaultProfileImage)} />
                    </div>
                    {/* Conditionally render the "Reset" button */}
                    {profileImage !== defaultProfileImage && (
                        <button onClick={() => handleResetButtonClick(setProfileImage, defaultProfileImage)} className="rounded-md bg-red-500 px-2 py-1 text-white">
                            Reset
                        </button>
                    )}
                </div>
                <div className=" flex  flex-col items-start justify-center   ">
                    <div className=" mb-4 flex items-center justify-evenly  ">
                        <Tippy content="dimension 200 x 200" placement="top">
                            <Image src={info_icon} width={20} height={20} alt="info" />
                        </Tippy>
                        <h3 className="mx-1 text-[13px] font-semibold">Logo</h3>
                    </div>
                    <div className="relative mb-4">
                        {users.map(
                            (userData) =>
                                userData.userProfiles.logoImage ? (
                                    // eslint-disable-next-line react/jsx-key, @next/next/no-img-element
                                    <img
                                        // src="./assets/images/coverImages/80009cc719caeb79a78dc659136d5308.jpeg"
                                        src={`./assets/logoImages/${userData.userProfiles.logoImage}.jpeg`}
                                        alt="Preview"
                                        width={160}
                                        height={160}
                                        className="rounded-md border border-gray-300 object-cover"
                                    />
                                ) : (
                                    // eslint-disable-next-line react/jsx-key, @next/next/no-img-element
                                    <img src={logoImage} width={160} height={160} alt="Preview" className=" h-40 w-40 rounded-[50%] border border-gray-300 object-cover" />
                                )
                            // eslint-disable-next-line react/jsx-key, @next/next/no-img-element
                        )}
                        {/* <img src={logoImage} width={160} height={160} alt="Preview" className=" h-40 w-40 rounded-[50%] border border-gray-300 object-cover" /> */}
                        <button
                            onClick={() => handleButtonClick('logoImageInput')}
                            className="absolute inset-0 flex h-full w-full items-center justify-center rounded-[50%] bg-black opacity-0 hover:opacity-25"
                        >
                            <span className="text-white">Change Image</span>
                        </button>
                        <input id="logoImageInput" type="file" accept="image/*" className="hidden" onChange={(event) => handleImageLogo(event, setLogoImage, defaultLogoImage)} />
                    </div>
                    {/* Conditionally render the "Reset" button */}
                    {logoImage !== defaultLogoImage && (
                        <button onClick={() => handleResetButtonClick(setLogoImage, defaultLogoImage)} className="rounded-md bg-red-500 px-2 py-1 text-white">
                            Reset
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default FileUpload;
