import React from 'react';
import Image from 'next/image';
import ProfileIcon from '../public/assets/images/icons/ProfileIcon.svg';
import MobileIcon from '../public/assets/images/icons/MobileIcon.svg';
import tapect_logo from '../public/assets/images/auth/tapect_logo.svg';
import Profile_Icon from '../public/assets/images/icons/Profile_Icon.svg';
import More from '../public/assets/images/icons/More.svg';
import { useState } from 'react';

const contact = () => {
    return (
        <>
            <div className=" h-[700px] border bg-white">
                <table>
                    <thead>
                        <tr className=" mt-2  h-[60px] w-full  bg-purple-BTNCOLOR">
                            <th className=" text-base font-medium">Select all</th>
                            <th className=" text-base font-medium">Contact</th>
                            <th className="text-base font-medium">Connected with</th>
                            <th className="text-base font-medium">Type</th>
                            <th className=" text-base font-medium">Date</th>
                            <th className=" text-base font-medium">Export</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr className="mt-2  h-[60px]  w-full  bg-purple-BGCOLOR">
                            <td>
                                <Image src={ProfileIcon} width={20} height={20} alt="profileicon"></Image>
                            </td>
                            <td>
                                <span className=" text-lg font-semibold">lorem Ipsum</span>
                            </td>
                            <td>
                                <Image src={tapect_logo} width={40} height={40} alt="tapectlogo"></Image>
                            </td>
                            <td>
                                <Image src={MobileIcon} width={10} height={10} alt="mobileicon"></Image>
                            </td>
                            <td>
                                <span className="text-base  font-normal text-[#515151]">21 Jan 2023</span>
                            </td>
                            <td>
                                <Image src={Profile_Icon} width={20} height={20} alt="profileicon"></Image>
                            </td>
                            <td>
                                <Image src={More} width={3} height={3} alt="more"></Image>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </>
    );
};

export default contact;
