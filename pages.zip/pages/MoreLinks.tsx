import React from 'react';
import Image from 'next/image';
import tabler_link from '../public/assets/images/icons/tabler_link.svg';
import document from '../public/assets/images/icons/document.svg';
import Delete from '../public/assets/images/icons/Delete.svg';
import QuickLink_Modal from './QuickLink_Modal';
import { useState } from 'react';

const MoreLinks = ({ formData, onFormChange }) => {
    const [showModal, setShowModal] = useState(false);

    const handleButtonClick = () => {
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
    };

    return (
        <>
            <div>
                <div>
                    <div className="flex justify-center">
                        <div className="mb-3 mt-7 flex h-[40px] w-[665px] items-center justify-between   ">
                            <span className="text-md  font-bold"> Links</span>
                            <button type="button" className="btn btn-primary my-2 w-[30vh]" onClick={handleButtonClick}>
                                +Add Additional Links
                            </button>
                        </div>
                    </div>
                    <div className="flex justify-center">
                        <div className="mt-3 flex h-[40px] w-[665px] items-center justify-between border-b  ">
                            <div className="  flex items-center">
                                <Image src={tabler_link} width={15} height={15} alt="tablerlink"></Image>
                                <span className="ml-2 font-normal ">tapect.io</span>
                            </div>
                            <Image src={Delete} width={15} height={15} alt="Delete"></Image>
                        </div>
                    </div>
                    <div className="flex justify-center">
                        <div className=" flex h-[40px] w-[665px] items-center justify-between ">
                            <div className=" flex items-center">
                                <Image src={document} width={12} height={12} alt="document"></Image>
                                <span className="ml-2 font-normal ">Docs</span>
                            </div>
                            <Image src={Delete} width={15} height={15} alt="Delete"></Image>
                        </div>
                    </div>
                </div>
                <div className="mt-4 flex justify-end">
                    <button type="button" className="mr-10 underline underline-offset-4">
                        Cancel
                    </button>

                    <button type="button" className="btn btn-primary mr-5  h-[40px] w-[130px]">
                        Update
                    </button>
                </div>
                <QuickLink_Modal isOpen={showModal} onClose={setShowModal} formData={formData} onFormChange={onFormChange}></QuickLink_Modal>
            </div>
        </>
    );
};

export default MoreLinks;
