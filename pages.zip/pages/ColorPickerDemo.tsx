import React, { useContext, useState, useEffect } from 'react';
import { useColorContext } from '../components/ColorContext';
import axios from 'axios';

const ColorPicker = ({ category, label, onChange }) => {
    const { backgroundColor, textColor, buttonColor, buttontextColor, updateBackgroundColor, updateTextColor, updateButtonColor, updateButtonTextColor, setFlag } = useColorContext();

    const [pickedColor, setPickedColor] = useState('');

    useEffect(() => {
        setPickedColor(getCategoryColor());
    }, [category, backgroundColor, textColor, buttonColor, buttontextColor]);

    const handleColorChange = async (newColor) => {
        // const newColor = event.target.value;

        setPickedColor(newColor);
        setFlag(1);
        switch (category) {
            case 'backgroundColor':
                updateBackgroundColor(newColor);
                break;
            case 'textColor':
                updateTextColor(newColor);
                break;
            case 'buttonColor':
                updateButtonColor(newColor);
                break;
            case 'buttontextColor':
                updateButtonTextColor(newColor);
                break;
            default:
                break;
        }

        try {
            const userId = localStorage.getItem('userId');
            if (!userId) {
                throw new Error('User ID not found in localStorage');
            }

            const response = await axios.post('http://localhost:3001/api/CustomizeProfile', {
                userId: userId,
                [category]: newColor, // dynamically set the category based on props
            });

            if (response.status === 200) {
                console.log(response.data.message); // log success message
            } else {
                console.error('Failed to customize theme:', response.statusText);
            }
        } catch (error) {
            console.error('Error occurred while customizing theme:', error);
        }
    };

    const getCategoryColor = () => {
        switch (category) {
            case 'backgroundColor':
                return backgroundColor;
            case 'textColor':
                return textColor;
            case 'buttonColor':
                return buttonColor;
            case 'buttontextColor':
                return buttontextColor;
            default:
                return '';
        }
    };

    return (
        <div className="flex flex-col items-start  justify-evenly">
            <h2 className="font-md p-2 text-left font-semibold">{label}</h2>
            <div className="flex items-center  rounded-md">
                <input type="color" value={pickedColor || getCategoryColor()} onChange={(e) => handleColorChange(e.target.value)} className=" h-[50px] w-[50px] bg-transparent" />
                <input
                    type="text"
                    value={pickedColor || getCategoryColor()}
                    placeholder="#000000"
                    onChange={(e) => handleColorChange(e.target.value)}
                    className="form-input h-[42px] w-40  text-base ltr:rounded-l-none rtl:rounded-r-none"
                />
            </div>
        </div>
    );
};

export default ColorPicker;
