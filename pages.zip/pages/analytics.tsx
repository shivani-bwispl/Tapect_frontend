import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { IRootState } from '../store';
import dynamic from 'next/dynamic';
import Dropdown from '../components/Dropdown';
import axios from 'axios'; // Import axios for making API requests
import axiosInstance from '../services/api'; // Import axiosInstance from api.js

const ReactApexChart = dynamic(() => import('react-apexcharts'), {
    ssr: false,
});
const analytics = () => {
    const [selectedOption, setSelectedOption] = useState('Daily Tapect');
    const options = ['Daily Tapect', 'Regional Wise', 'Contact Share', 'Date Wise'];

    const [chartVisibility, setChartVisibility] = useState({
        'Daily Tapect': true,
        'Regional Wise': false,
        'Contact Share': false,
        'Date Wise': false,
    });
    const [loginHistory, setLoginHistory] = useState([]); // State to store login history data

    const handleSelect = (selectedOption) => {
        console.log('Selected option:', selectedOption);

        // Set visibility for the selected chart to true and hide the rest
        setChartVisibility({
            'Daily Tapect': selectedOption === 'Daily Tapect',
            'Regional Wise': selectedOption === 'Regional Wise',
            'Contact Share': selectedOption === 'Contact Share',
            'Date Wise': selectedOption === 'Date Wise',
        });
        setSelectedOption(selectedOption);

        // Add your logic here to handle the selected option
    };

    const isDark = useSelector((state: IRootState) => state.themeConfig.theme === 'dark' || state.themeConfig.isDarkMode);
    const isRtl = useSelector((state: IRootState) => state.themeConfig.rtlClass) === 'rtl' ? true : false;

    // simpleColumnStackedOptions
    // const simpleColumnStacked: any = {
    //     series: [
    //         {
    //             name: 'PRODUCT A',
    //             data: [44, 55, 41, 67, 22, 43],
    //         },
    //         {
    //             name: 'PRODUCT B',
    //             data: [13, 23, 20, 8, 13, 27],
    //         },
    //     ],
    //     options: {
    //         chart: {
    //             height: 300,
    //             type: 'bar',
    //             stacked: true,
    //             zoom: {
    //                 enabled: false,
    //             },
    //             toolbar: {
    //                 show: false,
    //             },
    //         },
    //         colors: ['#2196F3', '#3B3F5C'],
    //         responsive: [
    //             {
    //                 breakpoint: 480,
    //                 options: {
    //                     legend: {
    //                         position: 'bottom',
    //                         offsetX: -10,
    //                         offsetY: 5,
    //                     },
    //                 },
    //             },
    //         ],
    //         plotOptions: {
    //             bar: {
    //                 horizontal: false,
    //             },
    //         },
    //         xaxis: {
    //             type: 'datetime',
    //             categories: ['01/01/2011 GMT', '01/02/2011 GMT', '01/03/2011 GMT', '01/04/2011 GMT', '01/05/2011 GMT', '01/06/2011 GMT'],
    //             axisBorder: {
    //                 color: isDark ? '#191E3A' : '#E0E6ED',
    //             },
    //         },
    //         yaxis: {
    //             opposite: isRtl ? true : false,
    //             labels: {
    //                 offsetX: isRtl ? -20 : 0,
    //             },
    //         },
    //         grid: {
    //             borderColor: isDark ? '#191E3A' : '#E0E6ED',
    //         },
    //         legend: {
    //             position: 'right',
    //             offsetY: 40,
    //         },
    //         tooltip: {
    //             theme: isDark ? 'dark' : 'light',
    //         },
    //         fill: {
    //             opacity: 0.8,
    //         },
    //     },
    // };
    // columnChartOptions
    const columnChart = {
        series: [
            {
                name: 'Net Profit',
                data: [44, 55, 57, 56, 61, 58, 63, 60, 66],
            },
            {
                name: 'Revenue',
                data: [76, 85, 101, 98, 87, 105, 91, 114, 94],
            },
        ],
        options: {
            chart: {
                height: 300,
                type: 'bar',
                zoom: {
                    enabled: false,
                },
                toolbar: {
                    show: false,
                },
            },
            colors: ['#805DCA', '#E7515A'],
            dataLabels: {
                enabled: false,
            },
            stroke: {
                show: true,
                width: 2,
                colors: ['transparent'],
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '55%',
                    endingShape: 'rounded',
                },
            },
            grid: {
                borderColor: isDark ? '#191E3A' : '#E0E6ED',
            },
            xaxis: {
                categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
                axisBorder: {
                    color: isDark ? '#191E3A' : '#E0E6ED',
                },
            },
            yaxis: {
                opposite: isRtl ? true : false,
                labels: {
                    offsetX: isRtl ? -10 : 0,
                },
            },
            tooltip: {
                theme: isDark ? 'dark' : 'light',
                y: {
                    formatter: function (val: any) {
                        return val;
                    },
                },
            },
        },
    };
    // // areaChartOptions
    // const areaChart: any = {
    //     series: [
    //         {
    //             name: 'Income',
    //             data: [16800, 16800, 15500, 17800, 15500, 17000, 19000, 16000, 15000, 17000, 14000, 17000],
    //         },
    //     ],
    //     options: {
    //         chart: {
    //             type: 'area',
    //             height: 300,
    //             zoom: {
    //                 enabled: false,
    //             },
    //             toolbar: {
    //                 show: false,
    //             },
    //         },
    //         colors: ['#805DCA'],
    //         dataLabels: {
    //             enabled: false,
    //         },
    //         stroke: {
    //             width: 2,
    //             curve: 'smooth',
    //         },
    //         xaxis: {
    //             axisBorder: {
    //                 color: isDark ? '#191E3A' : '#E0E6ED',
    //             },
    //         },
    //         yaxis: {
    //             opposite: isRtl ? true : false,
    //             labels: {
    //                 offsetX: isRtl ? -40 : 0,
    //             },
    //         },
    //         labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    //         legend: {
    //             horizontalAlign: 'left',
    //         },
    //         grid: {
    //             borderColor: isDark ? '#191E3A' : '#E0E6ED',
    //         },
    //         tooltip: {
    //             theme: isDark ? 'dark' : 'light',
    //         },
    //     },
    // };
    // // mixedChartOptions
    // const mixedChart: any = {
    //     series: [
    //         {
    //             name: 'TEAM A',
    //             type: 'column',
    //             data: [23, 11, 22, 27, 13, 22, 37, 21, 44, 22, 30],
    //         },
    //         {
    //             name: 'TEAM B',
    //             type: 'area',
    //             data: [44, 55, 41, 67, 22, 43, 21, 41, 56, 27, 43],
    //         },
    //         {
    //             name: 'TEAM C',
    //             type: 'line',
    //             data: [30, 25, 36, 30, 45, 35, 64, 52, 59, 36, 39],
    //         },
    //     ],
    //     options: {
    //         chart: {
    //             height: 300,
    //             // stacked: false,
    //             zoom: {
    //                 enabled: false,
    //             },
    //             toolbar: {
    //                 show: false,
    //             },
    //         },
    //         dataLabels: {
    //             enabled: false,
    //         },
    //         colors: ['#2196F3', '#00AB55', '#4361EE'],
    //         stroke: {
    //             width: [0, 2, 2],
    //             curve: 'smooth',
    //         },
    //         plotOptions: {
    //             bar: {
    //                 columnWidth: '50%',
    //             },
    //         },
    //         fill: {
    //             opacity: [1, 0.25, 1],
    //         },
    //         labels: ['01/01/2022', '02/01/2022', '03/01/2022', '04/01/2022', '05/01/2022', '06/01/2022', '07/01/2022', '08/01/2022', '09/01/2022', '10/01/2022', '11/01/2022'],
    //         markers: {
    //             size: 0,
    //         },
    //         xaxis: {
    //             type: 'datetime',
    //             axisBorder: {
    //                 color: isDark ? '#191E3A' : '#E0E6ED',
    //             },
    //         },
    //         yaxis: {
    //             title: {
    //                 text: 'Points',
    //             },
    //             min: 0,
    //             opposite: isRtl ? true : false,
    //             labels: {
    //                 offsetX: isRtl ? -10 : 0,
    //             },
    //         },
    //         grid: {
    //             borderColor: isDark ? '#191E3A' : '#E0E6ED',
    //         },
    //         tooltip: {
    //             shared: true,
    //             intersect: false,
    //             theme: isDark ? 'dark' : 'light',
    //         },
    //         legend: {
    //             itemMargin: {
    //                 horizontal: 4,
    //                 vertical: 8,
    //             },
    //         },
    //     },
    // };

    // Fetch login history data
    useEffect(() => {
        fetchLoginHistory();
    }, []);

    const fetchLoginHistory = async () => {
        try {
            const userId = localStorage.getItem('userId');
            if (!userId) {
                throw new Error('User ID not found in localStorage');
            }

            const response = await axiosInstance.get(`/login/login-history/${userId}`);
            const loginHistoryData = response.data.loginHistory;
            setLoginHistory(loginHistoryData);
        } catch (error) {
            console.error('Error fetching login history:', error.message);
        }
    };

    // Filter login history data for "Daily Tapect" and "Date Wise" charts
    const filteredLoginHistory = loginHistory.filter((item) => {
        return selectedOption === 'Daily Tapect' || selectedOption === 'Date Wise' || selectedOption === 'Regional Wise' || selectedOption === 'Contact Shared';
    });

    const renderChart = () => {
        switch (selectedOption) {
            case 'Daily Tapect':
                return (
                    <ReactApexChart
                        series={[
                            {
                                name: 'Daily Tapect',
                                data: filteredLoginHistory.map((item) => item?.count ?? 0), // Add null check and fallback to 0
                            },
                        ]}
                        options={{
                            chart: {
                                type: 'line',
                            },
                            xaxis: {
                                type: 'datetime', // set x-axis type to datetime
                                categories: filteredLoginHistory.map((item) => item?.date ?? ''), // Assuming date is in a valid format
                                labels: {
                                    format: 'dd/MM/yy', // set the format for x-axis labels
                                }, // Add null check and fallback to empty string
                            },
                            // Other options as needed
                        }}
                        className="w-full rounded-lg bg-white dark:bg-black"
                        type="line"
                        height={500}
                        width={'100%'}
                    />
                );
            case 'Date Wise':
                return (
                    <ReactApexChart
                        series={[
                            {
                                name: 'Date Wise',
                                data: filteredLoginHistory.map((item) => item?.count ?? 0), // Add null check and fallback to 0
                            },
                        ]}
                        options={{
                            chart: {
                                type: 'bar',
                            },
                            xaxis: {
                                type: 'datetime', // set x-axis type to datetime
                                categories: filteredLoginHistory.map((item) => item?.date ?? ''), // Assuming date is in a valid format
                                labels: {
                                    format: 'MM/dd/yy', // set the format for x-axis labels
                                },
                            },
                            // Other options as needed
                        }}
                        className="w-full rounded-lg bg-white dark:bg-black"
                        type="bar"
                        height={500}
                        width={'100%'}
                    />
                );
            case 'Regional Wise':
                return (
                    <ReactApexChart
                        series={[
                            {
                                name: 'Regional Wise',
                                data: filteredLoginHistory.map((item) => item?.count ?? 0), // Add null check and fallback to 0
                            },
                        ]}
                        options={{
                            chart: {
                                type: 'bar',
                            },
                            xaxis: {
                                categories: filteredLoginHistory.map((item) => item?.date ?? ''), // Add null check and fallback to empty string
                            },
                            // Other options as needed
                        }}
                        className="w-full rounded-lg bg-white dark:bg-black"
                        type="bar"
                        height={500}
                        width={'100%'}
                    />
                );
            case 'Contact Share':
                return (
                    <ReactApexChart
                        series={[
                            {
                                name: 'Contact Share',
                                data: filteredLoginHistory.map((item) => item?.count ?? 0), // Add null check and fallback to 0
                            },
                        ]}
                        options={{
                            chart: {
                                type: 'bar',
                            },
                            xaxis: {
                                categories: filteredLoginHistory.map((item) => item?.date ?? ''), // Add null check and fallback to empty string
                            },
                            // Other options as needed
                        }}
                        className="w-full rounded-lg bg-white dark:bg-black"
                        type="bar"
                        height={500}
                        width={'100%'}
                    />
                );
            default:
                return null;
        }
    };

    return (
        <>
            <div className="h-[calc(100vh)] overflow-y-auto px-5">
                <div className="m-3 flex items-center justify-between">
                    <h2 className="text-2xl font-semibold dark:text-white"> Analytics</h2>
                    <Dropdown options={options} onSelect={handleSelect} defaultValue={selectedOption} />
                </div>

                <div className="panel z-0 my-5 w-full">
                    {chartVisibility[selectedOption] && (
                        <div>
                            <div className="mb-5 flex items-center justify-between">
                                <h5 className="text-lg font-semibold dark:text-white">{selectedOption}</h5>
                            </div>
                            {renderChart()}
                        </div>
                    )}
                </div>
            </div>
            {/* <div className="h-[calc(100vh)] overflow-y-auto px-5">
                <div className="m-3 flex items-center justify-between">
                    <h2 className="text-2xl font-semibold dark:text-white"> Analytics</h2>
                    <Dropdown options={options} onSelect={handleSelect} defaultValue={selectedOption} />
                </div>

                <div className="panel my-5 w-full">
                    {chartVisibility['Daily Tapect'] && (
                        <div>
                            <div className="mb-5 flex items-center justify-between">
                                <h5 className="text-lg font-semibold dark:text-white">Daily Tapect</h5>
                            </div>
                            <ReactApexChart
                                series={simpleColumnStacked.series}
                                options={simpleColumnStacked.options}
                                className="w-full rounded-lg bg-white dark:bg-black"
                                type="bar"
                                height={500}
                                width={'100%'}
                            />
                        </div>
                    )}

                    {chartVisibility['Regional Wise'] && (
                        <div>
                            <div className="mb-5 flex items-center justify-between">
                                <h5 className="text-lg font-semibold dark:text-white">Regional Wise</h5>
                            </div>
                            <div className="mb-5">
                                <ReactApexChart
                                    series={columnChart.series}
                                    options={columnChart.options}
                                    className=" h-[500px] w-full rounded-lg bg-white dark:bg-black"
                                    type="bar"
                                    height={500}
                                    width={'100%'}
                                />
                            </div>
                        </div>
                    )}

                    {chartVisibility['Contact Share'] && (
                        <div>
                            <div className="mb-5 flex items-center justify-between">
                                <h5 className="text-lg font-semibold dark:text-white">Contact Share</h5>
                            </div>
                            <div className="mb-5">
                                <ReactApexChart series={areaChart.series} options={areaChart.options} className="rounded-lg bg-white dark:bg-black" type="area" height={500} width={'100%'} />
                            </div>
                        </div>
                    )}

                    {chartVisibility['Date Wise'] && (
                        <div>
                            <div className="mb-5 flex items-center justify-between">
                                <h5 className="text-lg font-semibold dark:text-white">Date Wise</h5>
                            </div>
                            <div className="mb-5">
                                <ReactApexChart series={mixedChart.series} options={mixedChart.options} className="rounded-lg bg-white dark:bg-black" type="bar" height={500} width={'100%'} />
                            </div>
                        </div>
                    )}
                </div>
            </div> */}
        </>
    );
};
export default analytics;
