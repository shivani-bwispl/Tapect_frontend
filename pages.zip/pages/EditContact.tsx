import React, { useEffect, useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { Fragment } from 'react';
import IconX from '@/components/Icon/IconX';
import Image from 'next/image';
import More from '../public/assets/images/icons/More.svg';
import ProfileIcon from '../public/assets/images/icons/ProfileIcon.svg';
import axios from 'axios';
import axiosInstance from '@/services/api';

const EditContact = ({ isOpen, onClose, contactId }) => {
    const [contactData, setContactData] = useState(null);
    const [formData, setFormData] = useState({
        fullname: '',
        contact_jobtitle: '',
        contact_phonenumber: '',
        contact_email: '',
        company: '',
        website: '',
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axiosInstance.put(`/contact_details/${contactId}`, formData);
            console.log('Contact updated:', response.data);
            onClose();
        } catch (error) {
            console.error('Error updating contact:', error);
        }
    };

    useEffect(() => {
        const fetchContactData = async () => {
            try {
                const response = await axiosInstance.get(`/contact_details/contactuser/${contactId}`);
                const ContactuserDetail = response.data.contact;

                console.log(ContactuserDetail);
                setContactData(ContactuserDetail);
                setFormData({
                    fullname: ContactuserDetail.fullname,
                    contact_jobtitle: ContactuserDetail.contact_jobtitle,
                    contact_phonenumber: ContactuserDetail.contact_phonenumber,
                    contact_email: ContactuserDetail.contact_email,
                    company: ContactuserDetail.company,
                    website: ContactuserDetail.website,
                });
            } catch (error) {
                console.error('Error fetching contact data:', error);
            }
        };

        if (isOpen && contactId) {
            fetchContactData();
        }
    }, [isOpen, contactId]);

    return (
        <>
            <div style={{ display: isOpen ? 'block' : 'none' }}>
                <Transition appear show={isOpen} as={Fragment}>
                    <Dialog as="div" open={isOpen} onClose={onClose}>
                        <Transition.Child
                            as={Fragment}
                            enter="ease-out duration-300"
                            enterFrom="opacity-0"
                            enterTo="opacity-100"
                            leave="ease-in duration-200"
                            leaveFrom="opacity-100"
                            leaveTo="opacity-0"
                        >
                            <div className="fixed inset-0" />
                        </Transition.Child>
                        <div className="fixed inset-0 z-[999] bg-[black]/60">
                            <div className="flex min-h-screen items-start justify-center px-4">
                                <Transition.Child
                                    as={Fragment}
                                    enter="ease-out duration-300"
                                    enterFrom="opacity-0 scale-95"
                                    enterTo="opacity-100 scale-100"
                                    leave="ease-in duration-200"
                                    leaveFrom="opacity-100 scale-100"
                                    leaveTo="opacity-0 scale-95"
                                >
                                    {/* <Dialog.Panel className="panel mx-auto my-auto  w-full overflow-x-hidden overflow-y-scroll rounded-[20px] border-0 bg-white px-6 py-6 text-black dark:text-white-dark sm:w-[500px] md:w-[890px]"> */}
                                    <div className="panel m-5 w-[900px]">
                                        <div className="flex  items-center justify-end  dark:bg-[#121c2c]">
                                            <button
                                                onClick={() => {
                                                    onClose(false);
                                                }}
                                                type="button"
                                                className="text-white-dark hover:text-dark"
                                            >
                                                <IconX className="mt-3 w-12" />
                                            </button>
                                        </div>
                                        <div className="flex  w-full items-center justify-between border-b-2 bg-white p-2">
                                            <div className="  flex  items-center justify-center  ">
                                                <Image src={ProfileIcon} width={50} height={50} alt="profileicon" className="ml-2"></Image>
                                                <span className="ml-2 text-2xl font-medium">{formData.fullname}</span>
                                            </div>
                                            {/* <div>
                                                    <Image src={More} width={5} height={5} alt="more"></Image>
                                                </div> */}
                                        </div>
                                        {formData && ( // Check if formData is not null
                                            <form onSubmit={handleSubmit} className="mb-5 bg-white p-4 dark:border-[#191e3a] dark:bg-black">
                                                <h6 className="mb-5 text-lg font-bold">Contact Information</h6>

                                                <div className="flex flex-col sm:flex-row">
                                                    <div className="mb-5 w-full sm:w-2/12 ltr:sm:mr-4 rtl:sm:ml-4">
                                                        <Image src={ProfileIcon} width={160} height={160} alt="profileicon" />
                                                    </div>
                                                    <div className="grid flex-1 grid-cols-1 gap-5 sm:grid-cols-2">
                                                        <div>
                                                            <label htmlFor="name">Full Name</label>
                                                            <input
                                                                id="name"
                                                                name="fullname"
                                                                type="text"
                                                                placeholder="Full Name"
                                                                className="form-input"
                                                                value={formData.fullname}
                                                                onChange={handleChange}
                                                            />
                                                        </div>
                                                        <div>
                                                            <label htmlFor="jobTitle">Job Title</label>
                                                            <input
                                                                id="jobTitle"
                                                                name="contact_jobtitle"
                                                                type="text"
                                                                placeholder="Job Title"
                                                                className="form-input"
                                                                value={formData.contact_jobtitle}
                                                                onChange={handleChange}
                                                            />
                                                        </div>
                                                        <div>
                                                            <label htmlFor="phoneNumber">Phone Number</label>
                                                            <input
                                                                id="phoneNumber"
                                                                name="contact_phonenumber"
                                                                type="text"
                                                                placeholder="Phone Number"
                                                                className="form-input"
                                                                value={formData.contact_phonenumber}
                                                                onChange={handleChange}
                                                            />
                                                        </div>
                                                        <div>
                                                            <label htmlFor="email">Email</label>
                                                            <input
                                                                id="contact_email"
                                                                name="contact_email"
                                                                type="email"
                                                                placeholder="Email"
                                                                className="form-input"
                                                                value={formData.contact_email}
                                                                onChange={handleChange}
                                                            />
                                                        </div>
                                                        <div>
                                                            <label htmlFor="company">Company</label>
                                                            <input
                                                                id="company"
                                                                name="company"
                                                                type="text"
                                                                placeholder="Company"
                                                                className="form-input"
                                                                value={formData.company}
                                                                onChange={handleChange}
                                                            />
                                                        </div>
                                                        <div>
                                                            <label htmlFor="website">Website</label>
                                                            <input
                                                                id="website"
                                                                name="website"
                                                                type="text"
                                                                placeholder="Website"
                                                                className="form-input"
                                                                value={formData.website}
                                                                onChange={handleChange}
                                                            />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="mt-7 flex items-center justify-end gap-5">
                                                    <button type="button" className="underline underline-offset-4" onClick={() => onClose(false)}>
                                                        Cancel
                                                    </button>
                                                    <button type="submit" className="btn btn-primary h-[40px] w-[130px]">
                                                        Update
                                                    </button>
                                                </div>
                                            </form>
                                        )}
                                    </div>
                                    {/* </Dialog.Panel> */}
                                </Transition.Child>
                            </div>
                        </div>
                    </Dialog>
                </Transition>
            </div>
        </>
    );
};

export default EditContact;

// import React, { useEffect, useState } from 'react';
// import { Dialog, Transition } from '@headlessui/react';
// import { Fragment } from 'react';
// import IconX from '@/components/Icon/IconX';
// import Image from 'next/image';
// import More from '../public/assets/images/icons/More.svg';
// import ProfileIcon from '../public/assets/images/icons/ProfileIcon.svg';
// import axios from 'axios';
// const EditContact = ({ isOpen, onClose, contactId }) => {
//     console.log(contactId,"EDITCONTACT");

//     const [contactData, setContactData] = useState(null);
//     const [formData, setFormData] = useState({
//         name: '',
//         jobTitle: '',
//         phoneNumber: '',
//         email: '',
//         company: '',
//         website: '',
//     });
//     const handleChange = (e) => {
//         const { name, value } = e.target;
//         setFormData({
//             ...formData,
//             [name]: value,
//         });
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
//         // Handle form submission here, e.g., submit the updated contact details
//         console.log('Submitted form data:', formData);
//         // Close the modal after submission
//         onClose();
//     };

//     useEffect(() => {
//         const fetchContactData = async () => {
//             try {
//                 const response = await axios.get(`http://localhost:3001/api/contact_details/contactuser/${contactId}`);
//                 console.log(response.data, 'Response.data');
//                 setContactData(response.data);
//                 // Set the form data with fetched contact data
//                 setFormData({
//                     name: response.data.fullname,
//                     jobTitle: response.data.contact_jobtitle,
//                     phoneNumber: response.data.contact_phonenumber,
//                     email: response.data.contact_email,
//                     company: response.data.company,
//                     website: response.data.website,
//                 });
//             } catch (error) {
//                 console.error('Error fetching contact data:', error);
//             }
//         };

//         if (isOpen && contactId) {
//             fetchContactData();
//         }
//     }, [isOpen, contactId]);
//     return (
//         <>
//             <div style={{ display: isOpen ? 'block' : 'none' }}>
//                 <Transition appear show={isOpen} as={Fragment}>
//                     <Dialog as="div" open={isOpen} onClose={onClose}>
//                         <Transition.Child
//                             as={Fragment}
//                             enter="ease-out duration-300"
//                             enterFrom="opacity-0"
//                             enterTo="opacity-100"
//                             leave="ease-in duration-200"
//                             leaveFrom="opacity-100"
//                             leaveTo="opacity-0"
//                         >
//                             <div className="fixed inset-0" />
//                         </Transition.Child>
//                         <div className="fixed inset-0 z-[999] bg-[black]/60">
//                             <div className="flex min-h-screen items-start justify-center px-4">
//                                 <Transition.Child
//                                     as={Fragment}
//                                     enter="ease-out duration-300"
//                                     enterFrom="opacity-0 scale-95"
//                                     enterTo="opacity-100 scale-100"
//                                     leave="ease-in duration-200"
//                                     leaveFrom="opacity-100 scale-100"
//                                     leaveTo="opacity-0 scale-95"
//                                 >
//                                     <Dialog.Panel className="panel mx-auto my-auto  w-full overflow-x-hidden overflow-y-scroll rounded-[20px] border-0 bg-white px-6 py-6 text-black dark:text-white-dark sm:w-[500px] md:w-[890px]">
//                                         <div className="flex  items-center justify-end  dark:bg-[#121c2c]">
//                                             <button
//                                                 onClick={() => {
//                                                     onClose(false);
//                                                 }}
//                                                 type="button"
//                                                 className="text-white-dark hover:text-dark"
//                                             >
//                                                 <IconX className="w-12" />
//                                             </button>
//                                         </div>
//                                         <div className="panel m-5 ">
//                                             <div className="flex  w-full items-center justify-between border-b-2 bg-white p-2">
//                                                 <div className="  flex  items-center justify-center  ">
//                                                     <Image src={ProfileIcon} width={50} height={50} alt="profileicon" className="ml-2"></Image>
//                                                     <span className="ml-2 text-2xl font-medium">John Doe </span>
//                                                 </div>
//                                                 <div>
//                                                     <Image src={More} width={5} height={5} alt="more"></Image>
//                                                 </div>
//                                             </div>
//                                             <form className="mb-5  bg-white p-4 dark:border-[#191e3a] dark:bg-black">
//                                                 <h6 className="mb-5 text-lg font-bold">Contact Information</h6>

//                                                 <div className="flex flex-col sm:flex-row">
//                                                     <div className="mb-5 w-full sm:w-2/12 ltr:sm:mr-4 rtl:sm:ml-4">
//                                                         <Image src={ProfileIcon} width={160} height={160} alt="profileicon"></Image>
//                                                     </div>
//                                                     <div className="grid flex-1 grid-cols-1 gap-5 sm:grid-cols-2">
//                                                         <div>
//                                                             <label htmlFor="name">Full Name</label>
//                                                             <input id="name" type="text" placeholder="Full Name" className="form-input" value={formData.name} onChange={handleChange} />
//                                                         </div>
//                                                         <div>
//                                                             <label htmlFor="profession">Job Title</label>
//                                                             <input id="jobTitle" type="text" placeholder="Job Title" className="form-input" value={formData.jobTitle} onChange={handleChange} />
//                                                         </div>
//                                                         <div>
//                                                             <label htmlFor="profession">Phone Number</label>
//                                                             <input
//                                                                 id="phoneNumber"
//                                                                 type="text"
//                                                                 placeholder="Phone Number"
//                                                                 className="form-input"
//                                                                 value={formData.phoneNumber}
//                                                                 onChange={handleChange}
//                                                             />
//                                                         </div>

//                                                         <div>
//                                                             <label htmlFor="address">Email</label>
//                                                             <input id="email" type="text" placeholder="Email" className="form-input" value={formData.email} onChange={handleChange} />
//                                                         </div>
//                                                         <div>
//                                                             <label htmlFor="location">Company</label>
//                                                             <input id="company" type="text" placeholder="Company" className="form-input" value={formData.company} onChange={handleChange} />
//                                                         </div>
//                                                         <div>
//                                                             <label htmlFor="phone">Website</label>
//                                                             <input id="website" type="text" placeholder="Website" className="form-input" value={formData.website} onChange={handleChange} />
//                                                         </div>
//                                                     </div>
//                                                 </div>
//                                                 <div className="mt-7  flex items-center justify-end gap-5 ">
//                                                     <button type="button" className="underline underline-offset-4" onClick={() => onClose(false)}>
//                                                         Cancel
//                                                     </button>
//                                                     <button type="button" className="btn btn-primary  h-[40px] w-[130px]">
//                                                         Update
//                                                     </button>
//                                                 </div>
//                                             </form>
//                                         </div>
//                                     </Dialog.Panel>
//                                 </Transition.Child>
//                             </div>
//                         </div>
//                     </Dialog>
//                 </Transition>
//             </div>
//         </>
//     );
// };

// export default EditContact;
