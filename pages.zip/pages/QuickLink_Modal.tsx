import React from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { Fragment, useState } from 'react';
import Image from 'next/image';
import { Tab } from '@headlessui/react';
import LinkIcon from '../public/assets/images/icons/LinkIcon.svg';
import Doc_Icon from '../public/assets/images/icons/Doc_Icon.svg';

import Search from './Search';
import RenderLinks from './RenderLinks';
import PLUS from '../public/assets/images/icons/PLUS.svg';

import IconX from '@/components/Icon/IconX';

const QuickLink_Modal = ({ isOpen, onClose, formData, onChange }) => {
    return (
        <>
            <div style={{ display: isOpen ? 'block' : 'none' }}>
                <Transition appear show={isOpen} as={Fragment}>
                    <Dialog as="div" open={isOpen} onClose={onClose}>
                        <Transition.Child
                            as={Fragment}
                            enter="ease-out duration-300"
                            enterFrom="opacity-0"
                            enterTo="opacity-100"
                            leave="ease-in duration-200"
                            leaveFrom="opacity-100"
                            leaveTo="opacity-0"
                        >
                            <div className="fixed inset-0" />
                        </Transition.Child>
                        <div className="fixed inset-0 z-[999] bg-[black]/60">
                            <div className="flex min-h-screen items-start justify-center px-4">
                                <Transition.Child
                                    as={Fragment}
                                    enter="ease-out duration-300"
                                    enterFrom="opacity-0 scale-95"
                                    enterTo="opacity-100 scale-100"
                                    leave="ease-in duration-200"
                                    leaveFrom="opacity-100 scale-100"
                                    leaveTo="opacity-0 scale-95"
                                >
                                    <Dialog.Panel className="panel my-8 h-[35vw] w-[40vw] max-w-5xl  overflow-x-hidden overflow-y-scroll rounded-[20px] border-0 bg-white p-0 px-5 py-5 text-black dark:text-white-dark">
                                        <div className="flex  items-center justify-end  dark:bg-[#121c2c]">
                                            <button onClick={() => onClose(false)} type="button" className="text-white-dark hover:text-dark">
                                                <IconX className="w-12" />
                                            </button>
                                        </div>
                                        <div className="flex justify-between">
                                            <h2 className=" w-fit px-5  text-[1.5vw] font-bold uppercase">Quick Links</h2>
                                        </div>

                                        <div className=" lg:col-span-2 xl:col-span-2">
                                            <div className="mb-5 ">
                                                <div id="border_top">
                                                    <div className="mb-5">
                                                        <Tab.Group>
                                                            <Tab.List className=" flex flex-wrap border-b border-white-light dark:border-[#191e3a]">
                                                                <Tab as={Fragment}>
                                                                    {({ selected }) => (
                                                                        <button
                                                                            className={`${selected ? 'border-b !border-secondary text-secondary !outline-none' : ''}
                                                    -mb-[1px] flex items-center border-transparent p-5 py-3 before:inline-block hover:border-b hover:!border-secondary hover:text-secondary`}
                                                                        >
                                                                            Links
                                                                        </button>
                                                                    )}
                                                                </Tab>
                                                                <Tab as={Fragment}>
                                                                    {({ selected }) => (
                                                                        <button
                                                                            className={`${selected ? 'border-b !border-secondary text-secondary !outline-none' : ''}
                                                -mb-[1px] flex items-center border-transparent p-5 py-3 before:inline-block hover:border-b hover:!border-secondary hover:text-secondary`}
                                                                        >
                                                                            Doc
                                                                        </button>
                                                                    )}
                                                                </Tab>
                                                            </Tab.List>

                                                            <Tab.Panels>
                                                                <Tab.Panel>
                                                                    <div className="mt-4 flex h-[40px] w-[200px] items-center justify-start ">
                                                                        <div className="ml-4">
                                                                            <Image src={LinkIcon} height={25} width={25} alt="link icon"></Image>
                                                                        </div>
                                                                        <div className="ml-5">
                                                                            <span className="text-2xl font-medium">Add link</span>
                                                                        </div>
                                                                    </div>
                                                                    <div className="m-4">
                                                                        <h2 className=" pb-2 text-sm font-normal">Link Title*</h2>
                                                                        <input
                                                                            name="LinkTitle"
                                                                            type="current password"
                                                                            placeholder="Link title"
                                                                            className=" form-input h-[45px]"
                                                                            onChange={onChange}
                                                                            value={formData.LinkTitle}
                                                                        />
                                                                    </div>
                                                                    <div className="m-4">
                                                                        <h2 className=" pb-2  text-sm font-normal">Link</h2>
                                                                        <input type="current password" placeholder="Link" className=" form-input h-[45px]" />
                                                                    </div>
                                                                    <div className=" mt-5 flex justify-end ">
                                                                        <button type="button" className="mr-10 underline underline-offset-4" onClick={() => onClose(false)}>
                                                                            Cancel
                                                                        </button>

                                                                        <button type="button" className="btn btn-primary mr-5 h-[40px] w-[130px]">
                                                                            Add link
                                                                        </button>
                                                                    </div>{' '}
                                                                </Tab.Panel>

                                                                <Tab.Panel>
                                                                    <div className="mt-4 flex h-[40px] w-[200px] items-center justify-start ">
                                                                        <div className="ml-4">
                                                                            <Image src={Doc_Icon} height={20} width={20} alt="doc icon"></Image>
                                                                        </div>
                                                                        <div className="ml-5">
                                                                            <span className="text-2xl font-medium">Add link</span>
                                                                        </div>
                                                                    </div>
                                                                    <div className="m-4">
                                                                        <h2 className=" pb-2 text-sm font-normal">File Title*</h2>
                                                                        <input
                                                                            type="current password"
                                                                            placeholder="File title"
                                                                            className=" form-input h-[45px]"
                                                                            name="FileTitle"
                                                                            onChange={onChange}
                                                                            value={formData.FileTitle}
                                                                        />
                                                                    </div>
                                                                    <div className="m-4">
                                                                        <h2 className=" pb-2 text-sm font-normal">File*</h2>
                                                                        <label htmlFor="file-upload" className="btn btn-primary mr-5 h-[40px] cursor-pointer text-base">
                                                                            Upload File
                                                                            <span className="text-xs">(Max file size 1MB)</span>
                                                                        </label>
                                                                        <input
                                                                            id="file-upload"
                                                                            type="file"
                                                                            className="hidden"
                                                                            accept=".pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx, image/*"
                                                                            // onChange={(e) => handleFileUpload(e.target.files)}
                                                                        />
                                                                    </div>
                                                                    <div className=" mt-5 flex justify-end ">
                                                                        <button type="button" className="mr-10 underline underline-offset-4" onClick={() => onClose(false)}>
                                                                            Cancel
                                                                        </button>
                                                                        <button type="button" className="btn btn-primary mr-5 h-[40px] w-[130px]">
                                                                            Add File
                                                                        </button>
                                                                    </div>{' '}
                                                                </Tab.Panel>
                                                            </Tab.Panels>
                                                        </Tab.Group>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </Dialog.Panel>
                                </Transition.Child>
                            </div>
                        </div>
                    </Dialog>
                </Transition>
            </div>
        </>
    );
};

export default QuickLink_Modal;
