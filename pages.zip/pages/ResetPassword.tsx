import Image from 'next/image';
import { useState, useEffect } from 'react';
import tapect_logo from '/public/assets/images/tapect_logo.svg';
import BlankLayout from '@/components/Layouts/BlankLayout';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import router, { useRouter } from 'next/router';
import axiosInstance from '@/services/api';

const ResetPassword = () => {
    const handleSubmit = async (e: { preventDefault: () => void }) => {
        e.preventDefault();

        try {
            const response = await axiosInstance.post('/forgotpassword', { email });
            debugger;
            if (response.status === 200 && response.data.success) {
                console.log('Password reset email sent successfully.');
                // Add your success notification or redirection logic here
                router.push('/verifyotp');
            }
        } catch (error) {
            console.error('Error sending password reset email:', error);
            // Add error handling logic here
        }
    };

    return (
        <div>
            <div className="relative box-border flex h-screen min-w-max items-center justify-center bg-white px-6 py-4 sm:px-10">
                <div className="relative w-full max-w-[900px] rounded-md " onSubmit={handleSubmit}>
                    <div className="relative flex flex-col justify-center bg-white">
                        <div className="min-w-screen/30 mx-auto flex flex-col items-center justify-center">
                            <Image src={tapect_logo} width={110} height={110} alt="logo " />
                            <div className="w-30px m-5 text-center">
                                <h1 className="text-lg font-bold !leading-snug text-dark">Verify Account</h1>
                            </div>
                            <form className="min-w-screen/50 w-[400px] space-y-3 rounded-lg border-2 border-solid border-white-light p-9 shadow-3xl dark:text-white">
                                <div className="mb-8">
                                    <span className=" text-xs">Your account is not verified.Please verify your account.</span>
                                </div>
                                <div>
                                    <label htmlFor="OTP" className="font-poppins  font-medium text-dark">
                                        Enter your email
                                    </label>
                                    <input type="text" className="form-input mb-12 border-2 ps-10 focus:border-btnColor-myColor" />
                                </div>
                                <div>
                                    <button type="submit" className="btn !mt-6 w-full border-0 bg-primary uppercase text-white hover:bg-btnColor-myColor">
                                        Continue
                                    </button>
                                </div>
                                <div>
                                    <span className="mt-3">Already have a tapect account?</span>
                                </div>
                            </form>
                            <div className="w-inherit flex items-center justify-evenly space-x-10 p-8 text-sm">
                                <span className="text-screen/1h text-gray">Help</span>
                                <span className="text-screen/1h text-gray">Privacy Policy</span>
                                <span className="text-screen/1h text-gray">Terms</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
ResetPassword.getLayout = (page: any) => {
    return <BlankLayout>{page}</BlankLayout>;
};
export default ResetPassword;

// import React, { useEffect, useState } from 'react';
// import BlankLayout from '@/components/Layouts/BlankLayout';
// import axios from 'axios';
// import { useRouter } from 'next/router';
// import { useDispatch } from 'react-redux';
// import { setPageTitle } from '@/store/themeConfigSlice';

// const ResetPassword = () => {
//     const [password, setPassword] = useState('');
//     const [confirmPassword, setConfirmPassword] = useState('');
//     const [isPasswordReset, setIsPasswordReset] = useState(false);
//     const [error, setError] = useState('');
//     const dispatch = useDispatch();
//     const router = useRouter();

//     useEffect(() => {
//         dispatch(setPageTitle('Reset Password'));
//         localStorage.removeItem('isLoggedIn');
//     }, [dispatch, router]);

//     const handleSubmit = async (e: any) => {
//         e.preventDefault();

//         if (password !== confirmPassword) {
//             setError('Passwords do not match');
//             return;
//         }

//         try {
//             // Make API call to reset password
//             const response = await axios.post('http://localhost:3001/api/resetPassword/', {
//                 email: 'email', // Replace with user's email
//                 resetToken: 'user.resetToken', // Replace with reset token received from email
//                 newPassword: password,
//             });

//             // If the request is successful, show success message
//             if (response.status === 200) {
//                 setIsPasswordReset(true);
//             }
//         } catch (error: any) {
//             if (error.response) {
//                 setError(error.response.data.message);
//             } else {
//                 setError('Failed to reset password. Please try again later.');
//             }
//             console.error('Error resetting password:', error);
//         }
//     };

//     return (
//         <div className="container mx-auto mt-8">
//             <h2 className="mb-4 text-2xl font-bold">Reset Password</h2>
//             {isPasswordReset ? (
//                 <div className="relative rounded border border-green-400 bg-green-100 px-4 py-3 text-green-700" role="alert">
//                     <strong className="font-bold">Password Reset!</strong>
//                     <span className="block sm:inline"> Your password has been successfully reset.</span>
//                 </div>
//             ) : (
//                 <form onSubmit={handleSubmit} className="mx-auto max-w-sm">
//                     {error && <div className="text-red-500">{error}</div>}
//                     <div className="mb-4">
//                         <label htmlFor="password" className="mb-2 block text-sm font-bold text-gray-700">
//                             New Password
//                         </label>
//                         <input
//                             type="password"
//                             id="password"
//                             placeholder="Enter your new password"
//                             value={password}
//                             onChange={(e) => setPassword(e.target.value)}
//                             required
//                             className="focus:shadow-outline w-full appearance-none rounded border px-3 py-2 leading-tight text-gray-700 shadow focus:outline-none"
//                         />
//                     </div>
//                     <div className="mb-6">
//                         <label htmlFor="confirmPassword" className="mb-2 block text-sm font-bold text-gray-700">
//                             Confirm Password
//                         </label>
//                         <input
//                             type="password"
//                             id="confirmPassword"
//                             placeholder="Confirm your new password"
//                             value={confirmPassword}
//                             onChange={(e) => setConfirmPassword(e.target.value)}
//                             required
//                             className="focus:shadow-outline w-full appearance-none rounded border px-3 py-2 leading-tight text-gray-700 shadow focus:outline-none"
//                         />
//                     </div>
//                     <div className="mb-6 text-center">
//                         <button type="submit" className="focus:shadow-outline rounded bg-blue-500 px-4 py-2 font-bold text-white hover:bg-blue-700 focus:outline-none">
//                             Reset Password
//                         </button>
//                     </div>
//                 </form>
//             )}
//         </div>
//     );
// };
// ResetPassword.getLayout = (page: any) => {
//     return <BlankLayout>{page}</BlankLayout>;
// };
// export default ResetPassword;
