import React, { useState } from 'react';
import { useEffect } from 'react';
const SocialContent = ({ socialName, image, onClose, Social, onNewItem, handleBackClick, isCustom, onChange, formData, DeleteEle, SelectedSocialItem, onUpdateItem }) => {
    console.log(socialName);

    let displayName = socialName;
    if (Social) {
        displayName += ' username';
    }

    // Initialize state based on whether todo is provided and matches socialName
    const [todoName, setTodoName] = useState(SelectedSocialItem && SelectedSocialItem.image.name === socialName ? SelectedSocialItem.name : '');
    const [link, setLink] = useState(SelectedSocialItem && SelectedSocialItem.image.name === socialName ? SelectedSocialItem.link : '');

    const [error, setError] = useState('');

    const [isEditing, setIsEditing] = useState(false);

    useEffect(() => {
        // Check if a todo item is passed and set editing mode accordingly
        if (SelectedSocialItem) {
            setIsEditing(true);
            setTodoName(SelectedSocialItem.name);
            setLink(SelectedSocialItem.link);
        } else {
            setIsEditing(false);
            setTodoName('');
            setLink('');
        }
    }, [SelectedSocialItem]);

    const handleNameChange = (event) => {
        setTodoName(event.target.value);
    };

    const handleLinkChange = (event) => {
        setLink(event.target.value);
    };

    const handleAction = async () => {
        if (!todoName || !link) {
            setError('Both fields are required');
            return;
        }

        try {
            if (isEditing) {
                onUpdateItem(todo.id, todoName, link);
            } else {
                const userId = localStorage.getItem('userId');
                if (!userId) {
                    throw new Error('User ID not found in localStorage');
                }

                const requestData = {
                    userId,
                    linktitle: link,
                    platform: socialName,
                    username: '',
                    wechat_number: '',
                    profile_link: '',
                    channel_link: '',
                    server_link: '',
                    telegram_link: '',
                    phone_number: '',
                    contact_number: '',
                    whatsapp_number: '',
                    email_address: '',
                    business_address: '',
                    facetime: '',
                    paypal_link: '',
                    payment_username: '',
                    spotify_link: '',
                    apple_link: '',
                    music_username: '',
                    image: '',
                    svg: '',
                    url: '',
                    icon: '',
                    businessId: '',
                    socialMediaId: '',
                    contactId: '',
                    paymentId: '',
                    musicId: '',
                };

                // Assuming you want to insert the input value into 'username' field
                requestData.username = todoName; // Use input value for 'username' field

                const response = await axios.post('http://localhost:3001/api/SocialLinks/', requestData);
                console.log(response.requestData); // Log the response from the server

                onNewItem(todoName, image, link);
            }

            setTodoName('');
            setLink('');
            setError('');
            handleBackClick();
        } catch (error) {
            console.error('Error:', error.message);
            // Handle error if needed
        }
    };

    return (
        <div className="p-6">
            <span className="text-[24px] tracking-wide"> Social Link</span>
            <div className="m-4 flex items-center">
                <div className="flex items-center space-x-2">
                    <img src={image.path} alt={displayName} className="h-12 w-12" />
                    <h1 className="text-lg font-medium capitalize">{image.platform}</h1>
                </div>
            </div>
            {isCustom === 'Custom Link' ? (
                <div>
                    <div className="m-4">
                        <h2 className=" pb-2 text-sm font-normal">Link Title</h2>
                        <input name="LinkTitle" type="current password" placeholder="Link title" className=" form-input h-[45px]" onChange={(onChange, handleNameChange)} value={todoName} />
                    </div>
                    <div className="m-4">
                        <h2 className=" pb-2  text-sm font-normal">Link</h2>
                        <input type="text" placeholder="Link" className=" form-input h-[45px]" value={link} onChange={handleLinkChange} />
                    </div>
                </div>
            ) : isCustom === 'File' ? (
                <div>
                    <div className="m-4">
                        <h2 className=" pb-2 text-sm font-normal">File Title*</h2>
                        <input type="current password" placeholder="File title" className=" form-input h-[45px]" name="FileTitle" onChange={onChange} value={formData.FileTitle} />
                    </div>
                    <div className="m-4">
                        <h2 className=" pb-2 text-sm font-normal">File*</h2>
                        <label htmlFor="file-upload" className="btn btn-primary mr-5 h-[40px] cursor-pointer text-base">
                            Upload File
                            <span className="text-xs">(Max file size 1MB)</span>
                        </label>
                        <input
                            id="file-upload"
                            type="file"
                            className="hidden"
                            accept=".pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx, image/*"
                            // onChange={(e) => handleFileUpload(e.target.files)}
                        />
                    </div>
                    {/* <div className=" mt-5 flex justify-end ">
                        <button type="button" className="mr-10 underline underline-offset-4" onClick={() => onClose(false)}>
                            Cancel
                        </button>
                        <button type="button" className="btn btn-primary mr-5 h-[40px] w-[130px]">
                            Add File
                        </button>
                    </div>{' '} */}
                </div>
            ) : (
                <div>
                    <div className="m-4 space-y-2">
                        <h2 className="pb-2 text-sm font-normal sm:text-base">{displayName}</h2>
                        <input type="text" placeholder={displayName} onChange={handleNameChange} value={todoName} className="form-input h-[45px] w-full" required />

                        <h2 className="pb-2 text-sm font-normal sm:text-base">Link</h2>
                        <input type="text" placeholder="Link" className="form-input h-[45px] w-full" value={link} onChange={handleLinkChange} required />
                    </div>
                    {error && <p className="text-red-500">{error}</p>}
                </div>
            )}
            <div className="flex justify-end ">
                <button type="button" className="mr-10 underline underline-offset-4" onClick={() => onClose(false)}>
                    Cancel
                </button>

                <button type="button" className="btn btn-primary mx-4 h-[40px] w-[130px] transition  duration-300 ease-in-out" onClick={handleAction}>
                    {isEditing ? 'Update' : 'Add Link'}
                </button>
            </div>
        </div>
    );
};

export default SocialContent;
