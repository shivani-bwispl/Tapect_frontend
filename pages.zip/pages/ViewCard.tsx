/* eslint-disable @next/next/no-img-element */
/* eslint-disable react/jsx-key */
import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import axios from 'axios';
import Share from '../public/assets/images/icons/Share';
import Call from '../public/assets/images/icons/Call';
import MailBox from '../public/assets/images/icons/MailBox';
import Download from '../public/assets/images/icons/Download';
import Location from '../public/assets/images/icons/Location';
import WebsiteIcon from '../public/assets/images/icons/WebsiteIcon';
import tapect_logo from '../public/assets/images/tapect_logo.svg';
import Linked_in from '../public/assets/images/icons/Linked_in';
import Instagram_card from '../public/assets/images/icons/Instagram_card';
import Facebook_card from '../public/assets/images/icons/Facebook_card';
import Twitter_card from '../public/assets/images/icons/Twitter_card';
import BlankLayout from '@/components/Layouts/BlankLayout';
import { useLeadCapture } from '../components/LeadCaptureContext';
import { useImageContext } from '../components/ImageContext';
import { useColorContext } from '../components/ColorContext';
import { useRouter } from 'next/dist/client/router';
import axiosInstance from '@/services/api';

const ViewCard = () => {
    const { showPhonenumberInput, showEmailInput, showCompanyInput, showWebsiteInput, showJobtitleInput }: any = useLeadCapture();

    const [isModalOpen, setIsModalOpen] = useState(false);

    const closeModal = () => {
        setIsModalOpen(false);
    };
    const openModal = () => {
        setIsModalOpen(true);
    };
    const CutomCardHeight = {
        height: '100dvh',
        // width: '350px',
    };

    // Define formData state and setFormData setter function
    const [contactformData, setFormData] = useState({
        fullname: '',
        contact_email: '',
        contact_phonenumber: '',
        contact_jobtitle: '',
        company: '',
        website: '',
        // Add more fields as needed
    });

    const { coverImage, profileImage, logoImage }: any = useImageContext();
    const { backgroundColor, textColor, buttonColor, buttonText, sketchPickerColor, sketchPickerLightColor, flag }: any = useColorContext();
    const [finalColor, setFinalColor] = useState({
        bgSub: '',
        bg: '#FFFFFF',
        buttonColor: '#652dbf',
        buttontextColor: '#000000',
        textColor: '#000000',
    });

    const [userProfiles, setUserProfiles] = useState([]);
    const [companyProfiles, setCompanyProfiles] = useState([]);
    const [socialLinks, setSocialLinks] = useState([]);
    const [error, setError] = useState(null);

    const [inputValue, setInputValue] = useState('');
    const router = useRouter();

    // Define handleInputChange function to update form data
    const handleInputChange = (event) => {
        const { name, value } = event.target;

        // Update form data state
        setFormData({
            ...contactformData,
            [name]: value,
        });
    };

    const [isHovered, setIsHovered] = useState(false);
    const [isHovered2, setIsHovered2] = useState(false);
    const buttonStyle = {
        background: isHovered ? `white` : buttonColor,
        color: isHovered ? `${textColor}` : buttonText,
        borderColor: isHovered ? `${textColor}` : '',
    };

    useEffect(() => {
        console.log('coverImage:', coverImage);
        console.log('profileImage:', profileImage);
        console.log('logoImage:', logoImage);
    }, [coverImage, profileImage, logoImage]);

    useEffect(() => {
        console.log('bg:', backgroundColor);
        console.log('textColor:', textColor);
    }, [backgroundColor, textColor]);

    const socialIcons = [
        <Linked_in buttonColor={buttonColor} textColor={textColor} />,
        <Facebook_card buttonColor={buttonColor} textColor={textColor} />,
        <Twitter_card buttonColor={buttonColor} textColor={textColor} />,
        <Instagram_card buttonColor={buttonColor} textColor={textColor} />,
        <Linked_in buttonColor={buttonColor} textColor={textColor} />,
        <Linked_in buttonColor={buttonColor} textColor={textColor} />,
        <Facebook_card buttonColor={buttonColor} textColor={textColor} />,
        <Twitter_card buttonColor={buttonColor} textColor={textColor} />,
        <Instagram_card buttonColor={buttonColor} textColor={textColor} />,
        <Linked_in buttonColor={buttonColor} textColor={textColor} />,
    ];
    const renderedIcons = socialIcons.map((icon, index) => (
        <div key={index} className="icon-container">
            {icon}
        </div>
    ));

    useEffect(() => {
        const fetchUserProfile = async () => {
            try {
                const userId = localStorage.getItem('userId');
                if (!userId) {
                    throw new Error('User ID not found in localStorage');
                }
                const response = await axiosInstance.get(`/profileUpdate/${userId}`);
                const userProfileData = response.data;
                setUserProfiles([userProfileData]);
            } catch (error) {
                console.error('Error fetching user profile:', error.message);
                setUserProfiles([]);
            }
        };

        fetchUserProfile();

        const fetchUserCompanyProfile = async () => {
            try {
                const userId = localStorage.getItem('userId');
                if (!userId) {
                    throw new Error('User ID not found in localStorage');
                }
                const response = await axiosInstance.get(`/CompanyProfile/${userId}`);
                const CompanyProfileData = response.data;
                setCompanyProfiles([CompanyProfileData]);
            } catch (error) {
                console.error('Error fetching user profile:', error.message);
                setCompanyProfiles([]);
            }
        };

        fetchUserCompanyProfile();
    }, []);

    const handleContactFormSubmit = async (contactformData) => {
        try {
            // Make API call to update company profile
            await handleContactUpdate(contactformData);
            // Optionally, perform any additional actions after successful update
            console.log('Company profile updated successfully');
        } catch (error) {
            console.error('Error updating company profile:', error.message);
            // Optionally, handle the error and display an error message to the user
        }
    };

    const handleContactUpdate = async (data) => {
        try {
            const userId = localStorage.getItem('userId');
            if (!userId) {
                throw new Error('User ID not found in localStorage');
            }

            // Include userId in the data object
            data.userId = userId;

            const response = await axiosInstance.post('/contact_details/', data);
            console.log(response.data); // Log the response from the server
            // Optionally, perform any additional actions after successful update
        } catch (error) {
            console.error('Error updating company profile:', error.message);
            throw error; // Rethrow the error to handle it in the caller function
        }
    };

    useEffect(() => {
        const fetchUserSocialLinks = async () => {
            try {
                const userId = localStorage.getItem('userId');
                if (!userId) {
                    throw new Error('User ID not found in localStorage');
                }
                const response = await axiosInstance.get(`/SocialLinks/${userId}`);
                const responseData = response.data;
                console.log(responseData, 'customcard');

                // Check if responseData.existingSocialLink exists and is an object
                if (responseData.existingSocialLink && typeof responseData.existingSocialLink === 'object') {
                    const socialMediaLinks = responseData.existingSocialLink.Social_Media || [];
                    const businessLinks = responseData.existingSocialLink.Business || [];
                    const contactLinks = responseData.existingSocialLink.Contact || [];
                    const paymentLinks = responseData.existingSocialLink.Payment || [];
                    const musicLinks = responseData.existingSocialLink.Music || [];

                    // Combine social media and business links into one array
                    const allSocialLinks = [...socialMediaLinks, ...businessLinks, ...contactLinks, ...musicLinks, ...paymentLinks];

                    // // Combine all social media arrays into one array
                    //   const allSocialLinks = Object.values(responseData.existingSocialLink).flat();
                    //   console.log(allSocialLinks, "allSocialLinks");

                    setSocialLinks(allSocialLinks);
                    console.log(allSocialLinks, 'allSocialLinks');
                } else {
                    throw new Error('Social links data is not in the expected format');
                }
            } catch (error) {
                console.error('Error fetching user social links:', error.message);
                setSocialLinks([]); // Reset social links state to an empty array
                setError('Error fetching user social links'); // Update error state
            }
        };

        fetchUserSocialLinks(); // Call fetchUserSocialLinks when the component mounts
    }, []);

    // Function to render platform icons dynamically
    const renderPlatformIcon = (platform) => {
        // Define a mapping between platform names and their corresponding icons
        const platformIcons = {
            linkedin: Linked_in,
            instagram: Instagram_card,
            facebook: Facebook_card,
            twitter: Twitter_card,
            // Add more platform names and their corresponding components here
        };

        // Check if the platform exists in the platformIcons mapping
        if (platformIcons.hasOwnProperty(platform)) {
            const PlatformComponent = platformIcons[platform];
            return <PlatformComponent buttonColor={flag === 0 ? finalColor.bgSub : finalColor.buttonColor} textColor={flag === 0 ? finalColor.bgSub : finalColor.textColor} />;
        } else {
            // Return a default icon or handle the case when the platform is not found
            return <img src="default-icon.png" alt="Default" />;
        }
    };

    return (
        <>
            {isModalOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center  bg-opacity-50">
                    <div className="relative mx-auto w-[300px] max-w-sm rounded-md border bg-white p-4">
                        <button className="absolute right-4 top-2 cursor-pointer text-2xl" onClick={closeModal}>
                            &times;
                        </button>
                        <form>
                            <div className=" ml-4 mt-3">
                                <span className="h-[30px] w-[90px] text-lg font-bold">Share your details</span>
                            </div>
                            <div className="mt-1 flex flex-col items-center justify-center px-2">
                                <div className="my-1">
                                    <input
                                        id="fullname"
                                        type="text"
                                        name="fullname"
                                        placeholder="Full Name"
                                        value={contactformData.fullname}
                                        onChange={(e) => {
                                            handleInputChange(e);
                                            setInputValue(e.target.value);
                                        }}
                                        className="form-input w-[230px] placeholder:text-xs placeholder:text-gray"
                                    />
                                </div>
                                {showEmailInput && (
                                    <div className="my-1">
                                        <input
                                            id="contact_email"
                                            type="email"
                                            placeholder="Email"
                                            name="contact_email"
                                            value={contactformData.contact_email}
                                            onChange={(e) => {
                                                handleInputChange(e);
                                                setInputValue(e.target.value);
                                            }}
                                            className="form-input w-[230px] placeholder:text-xs placeholder:text-gray"
                                        />
                                    </div>
                                )}
                                {showPhonenumberInput && (
                                    <div className="my-1">
                                        <input
                                            id="contact_phonenumber"
                                            type="tel"
                                            placeholder="Phone number"
                                            name="contact_phonenumber"
                                            value={contactformData.contact_phonenumber}
                                            onChange={(e) => {
                                                handleInputChange(e);
                                                setInputValue(e.target.value);
                                            }}
                                            className="form-input w-[230px] placeholder:text-xs placeholder:text-gray"
                                        />
                                    </div>
                                )}
                                {showJobtitleInput && (
                                    <div className="my-1">
                                        <input
                                            id="contact_jobtitle"
                                            type="text"
                                            placeholder="Job title"
                                            name="contact_jobtitle"
                                            value={contactformData.contact_jobtitle}
                                            onChange={(e) => {
                                                handleInputChange(e);
                                                setInputValue(e.target.value);
                                            }}
                                            className="form-input w-[230px] placeholder:text-xs placeholder:text-gray"
                                        />
                                    </div>
                                )}
                                {showCompanyInput && (
                                    <div className="my-1">
                                        <input
                                            id="company"
                                            type="text"
                                            placeholder="Company"
                                            name="company"
                                            value={contactformData.company}
                                            onChange={(e) => {
                                                handleInputChange(e);
                                                setInputValue(e.target.value);
                                            }}
                                            className="form-input w-[230px] placeholder:text-xs placeholder:text-gray"
                                        />
                                    </div>
                                )}
                                {showWebsiteInput && (
                                    <div className="my-1">
                                        <input
                                            id="website"
                                            type="text"
                                            placeholder="Website"
                                            value={contactformData.website}
                                            onChange={(e) => {
                                                handleInputChange(e);
                                                setInputValue(e.target.value);
                                            }}
                                            className="form-input w-[230px] placeholder:text-xs placeholder:text-gray"
                                        />
                                    </div>
                                )}
                                <div className="my-3">
                                    <button type="button" onClick={() => handleContactFormSubmit(contactformData)} className="btn btn-primary h-[40px] w-[230px] text-base">
                                        Submit
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            )}
            {isModalOpen && <div className="absolute z-40 h-full w-full bg-black bg-opacity-50 backdrop-blur-sm"></div>}
            <div className="flex min-h-screen flex-col items-center justify-center bg-gray-100">
                <div
                    className={`mx-auto mb-8 mt-8 grid  w-[30vw] overflow-y-auto overflow-x-hidden rounded-3xl border md:grid-cols-1 xl:grid-cols-1`}
                    style={{ ...CutomCardHeight, backgroundColor, color: textColor }}
                >
                    <div className="relative mb-8 mt-[-4px] border-white-light dark:border-[#1b2e4b]">
                        {/* {coverImage && <img src={coverImage} alt="cardImage" width={500} height={500} className=" min-h-full w-full object-cover" />}
                        <div className="absolute bottom-[-5vh] left-[3vh] h-20 w-20 rounded-full border border-solid border-white bg-gray-lightGray">
                            <img src={profileImage} alt="profileImage" width={500} height={500} className="h-full w-full rounded-full object-cover" />
                        </div>
                        <div className="absolute bottom-[-5vh] left-[10vh] flex items-center justify-center rounded-full border border-black">
                            <img src={logoImage} width={45} height={45} alt="profilelogo" className="rounded-full" />
                        </div> */}
                        {userProfiles.map((userProfileData, index) => (
                            <div key={index} className="relative mb-8 mt-[-4px] border-white-light dark:border-[#1b2e4b]">
                                {userProfileData.coverImage && <img src={userProfileData.coverImage} alt="cardImage" width={500} height={500} className="min-h-full w-full object-cover" />}
                                <div className="absolute bottom-[-5vh] left-[3vh] h-20 w-20 rounded-full border border-solid border-white bg-gray-lightGray">
                                    {userProfileData.profileImage && (
                                        <img src={userProfileData.profileImage} alt="profileImage" width={160} height={160} className="h-full w-full rounded-full object-cover" />
                                    )}
                                </div>
                                <div className="absolute bottom-[-5vh] left-[10vh] flex items-center justify-center rounded-full border border-black">
                                    {userProfileData.logoImage && <img src={userProfileData.logoImage} width={45} height={45} alt="profilelogo" className="rounded-full" />}
                                </div>
                            </div>
                        ))}
                    </div>
                    <div className="flex flex-col px-6 py-4">
                        <div className="mb-2 font-normal">
                            {userProfiles.map((userProfilesData) => (
                                <React.Fragment key={userProfilesData}>
                                    <h1 className="my-2 text-[20px] font-bold">
                                        {`
                      ${userProfilesData['first_name']} 
                      ${userProfilesData['last_name']}
                    `}
                                    </h1>
                                    <h6 className="my-2 font-normal">
                                        {`
                      ${userProfilesData['job_title']} At
                      ${userProfilesData['organization_name']} 
                    `}
                                    </h6>
                                    <div className="flex items-center justify-start">
                                        <Call textColor={textColor}></Call>
                                        <div className="my-2 ml-2 font-normal">
                                            <a href={`tel:${userProfilesData['phone_number']}`}>{userProfilesData['phone_number']}</a>
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-start">
                                        <MailBox className="mr-5" textColor={textColor}></MailBox>
                                        <div className="my-2 ml-3 font-normal">
                                            <a href={`mailto:${userProfilesData['profile_email']}`}>{userProfilesData['profile_email']}</a>
                                        </div>
                                    </div>
                                    <div className="my-2 flex w-full flex-col items-start justify-center overflow-y-auto overflow-x-hidden overscroll-contain">
                                        <div className="text-md overflow-auto overscroll-contain">
                                            {`
                      ${userProfilesData['note']} 
                     
                    `}
                                        </div>
                                    </div>
                                </React.Fragment>
                            ))}
                        </div>
                        <div className="social-icons-container mb-2 grid grid-cols-5 gap-4 sm:grid-cols-5 md:grid-cols-5 lg:grid-cols-5">
                            {error && <p>{error}</p>}
                            {socialLinks.map((link, index) => (
                                <div key={index}>
                                    {renderPlatformIcon(link.platform)}
                                    <a href={link.url}>{}</a>
                                </div>
                            ))}
                        </div>
                        <>
                            <span className="my-3 text-[20px] font-bold">Quick Links</span>
                            <div className="w-full  px-2">
                                <div className="flex items-center justify-between">
                                    <span className="text-md font-semibold ">Tapect</span>
                                    <div className="h-[30px] w-[30px] ">
                                        <Share textColor={textColor}></Share>
                                    </div>
                                </div>
                                <div className="flex items-center justify-between">
                                    <span className="text-md font-semibold">File Title</span>
                                    <div className="h-[30px] w-[30px] ">
                                        <Download textColor={textColor}></Download>
                                    </div>
                                </div>
                            </div>
                        </>
                        {companyProfiles.map((CompanyProfileData) => (
                            <React.Fragment key={CompanyProfileData}>
                                <div className="mb-3 mt-5 flex w-full flex-wrap items-center justify-start pr-4 text-[20px] font-bold">
                                    {`
                      ${CompanyProfileData['company_name']} 
                    `}
                                </div>
                                <div className="my-4 flex w-full items-start">
                                    <Location textColor={textColor} className="h-9 w-9 flex-shrink-0"></Location>
                                    <div className=" ml-2 flex flex-col flex-wrap" style={{ width: '350px' }}>
                                        <span className="text-md break-all px-2 font-normal">
                                            {`
                     ${CompanyProfileData['street_address']},
                     ${CompanyProfileData['city']} ,
                     ${CompanyProfileData['state']},
                     ${CompanyProfileData['country']},
                     ${CompanyProfileData['post_code']}
                    `}
                                        </span>
                                    </div>
                                </div>
                                <div className="my-4 flex w-full items-start">
                                    <Call textColor={textColor} className="h-9 w-9 flex-shrink-0"></Call>
                                    <div className="ml-2 flex flex-col flex-wrap" style={{ width: '200px' }}>
                                        <span className="text-md break-all px-2 font-normal">
                                            {`
                      ${CompanyProfileData['company_contact']} 
                    `}{' '}
                                        </span>
                                    </div>
                                </div>
                                <div className="my-4 flex items-start">
                                    <WebsiteIcon textColor={textColor} className="h-9 w-9 flex-shrink-0"></WebsiteIcon>
                                    <div className="ml-2 flex flex-col flex-wrap" style={{ width: '200px' }}>
                                        <span className="text-md break-all px-2 font-normal">
                                            {`
                      ${CompanyProfileData['website']} 
                    `}
                                        </span>
                                    </div>
                                </div>
                                <div>
                                    <button
                                        type="button"
                                        className="btn my-4 w-full"
                                        style={{ background: buttonColor, color: buttonText }}
                                        onMouseEnter={() => setIsHovered(true)}
                                        onMouseLeave={() => setIsHovered(false)}
                                    >
                                        Save as Contact
                                    </button>
                                    <button type="button" className="btn mb-7 w-full" style={{ color: textColor, borderColor: textColor }} onClick={openModal}>
                                        Share your details
                                    </button>
                                </div>
                            </React.Fragment>
                        ))}
                        <div className=" flex items-center justify-center  p-2">
                            <Image src={tapect_logo} width={80} height={80} alt="tapectlogo"></Image>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};
ViewCard.getLayout = (page: any) => {
    return <BlankLayout>{page}</BlankLayout>;
};

export default ViewCard;
