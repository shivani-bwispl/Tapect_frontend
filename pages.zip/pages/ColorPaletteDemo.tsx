import React from 'react';
import Image from 'next/image';
import { useState } from 'react';
import { SketchPicker } from 'react-color';
import { useColorContext } from '../components/ColorContext';
import colorDropper from '../public/assets/images/icons/colorDropper.png';

const ColorPalette = () => {
    const { sketchPickerColor, updateSketchPickerColor, sketchPickerLightColor, updateSketchPickerLightColor, setFlag } = useColorContext();
    const [showDropper, setshowDropper] = useState(false);
    const [color, setcolor] = useState(sketchPickerColor);
    const [lightColor, setLightColor] = useState('');
    // Check if the context values are provided correctly
    if (!sketchPickerColor || !updateSketchPickerColor) {
        console.error('Color context values are not provided correctly');
        return null;
    }

    const handleColorChange = (color) => {
        const { r, g, b } = color.rgb;
        const newColor = `rgba(${r}, ${g}, ${b}, 1)`; // Full opacity color
        const lightColor = `rgba(${r}, ${g}, ${b}, 0.28)`; // Light color with 0.28 opacity
        setcolor(newColor);
        updateSketchPickerColor(newColor);
        setLightColor(lightColor); // Set the light Color
        updateSketchPickerLightColor(lightColor); // Update the light color in the context
        setFlag(0);
    };
    const handlePredefinedColorClick = (color) => {
        const lightColor = `rgba(${parseInt(color.slice(1, 3), 16)}, ${parseInt(color.slice(3, 5), 16)}, ${parseInt(color.slice(5, 7), 16)}, 0.28)`;

        updateSketchPickerColor(color);
        setLightColor(lightColor); // Set the light Color
        updateSketchPickerLightColor(lightColor); // Update the light color in the context
        setFlag(0);
    };
    const handleImageClick = () => {
        setshowDropper(!showDropper);
    };
    const predefinedColors = ['#FF1616', '#FF914D', '#FFDE59', '#7ED957', '#5271FF', '#7F00FF', '#000000'];
    return (
        <>
            <div>
                <h1 className="m-4 text-left text-lg">Profile Theme</h1>
                <div className=" w-full  p-3">
                    <h2 className="font-md p-3 text-left font-semibold">Select Theme Color</h2>
                    <ul className="flex items-center justify-evenly">
                        <li className="relative h-8 w-8 rounded-[50%] border border-zinc-400">
                            <Image src={colorDropper} alt="color dropper" id="dropper" onClick={handleImageClick} />
                            {showDropper && <SketchPicker color={color} onChange={handleColorChange} className="absolute top-[40px]" />}
                        </li>
                        {predefinedColors.map((color, index) => (
                            <li key={index} style={{ backgroundColor: color }} className="h-8 w-8 rounded-[50%] border" onClick={() => handlePredefinedColorClick(color)}></li>
                        ))}
                    </ul>

                    <h2 className="font-md mx-3  my-5 text-left font-semibold ">Customize Theme </h2>
                </div>
            </div>
        </>
    );
};

export default ColorPalette;
