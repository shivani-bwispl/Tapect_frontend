import axiosInstance from '@/services/api';
import axios from 'axios';
import React, { useState, useEffect } from 'react';

const SocialContent = ({ socialName, image, onClose, Social, onNewItem, handleBackClick, isCustom, onChange, formData, DeleteEle, todo, onUpdateItem }: any) => {
    let displayName = socialName;
    if (Social) {
        displayName += ' username';
    }

    const [todoName, setTodoName] = useState('');
    const [link, setLink] = useState('');
    const [error, setError] = useState('');
    const [isEditing, setIsEditing] = useState(false);

    useEffect(() => {
        if (todo) {
            setIsEditing(true);
            setTodoName(todo.name);
            setLink(todo.link);
        } else {
            setIsEditing(false);
            setTodoName('');
            setLink('');
        }
    }, [todo]);

    const handleNameChange = (event) => {
        setTodoName(event.target.value);
    };

    const handleLinkChange = (event) => {
        setLink(event.target.value);
    };

    const handleAction = async () => {
        if (!todoName || !link) {
            setError('Both fields are required');
            return;
        }

        try {
            if (isEditing) {
                onUpdateItem(todo.id, todoName, link);
            } else {
                const userId = localStorage.getItem('userId');
                if (!userId) {
                    throw new Error('User ID not found in localStorage');
                }

                const requestData = {
                    userId,
                    linktitle: link,
                    platform: socialName,
                    username: '',
                    wechat_number: '',
                    profile_link: '',
                    channel_link: '',
                    server_link: '',
                    telegram_link: '',
                    phone_number: '',
                    contact_number: '',
                    whatsapp_number: '',
                    email_address: '',
                    business_address: '',
                    facetime: '',
                    paypal_link: '',
                    payment_username: '',
                    spotify_link: '',
                    apple_link: '',
                    music_username: '',
                    image: '',
                    svg: '',
                    url: '',
                    icon: '',
                    businessId: '',
                    socialMediaId: '',
                    contactId: '',
                    paymentId: '',
                    musicId: '',
                };

                // Map of platform names to corresponding field names
                const platformFields = {
                    // Add mappings for all supported platforms
                    instagram: ['username'],
                    linkedin: ['profile_link'],
                    facebook: ['profile_link'],
                    message: ['username'],
                    email: ['username'],
                    website: ['url'],
                    paypal: ['paypal_link'],
                    googlemap: ['url'],
                    facetime: ['facetime'],
                    whatsapp: ['whatsapp_number'],
                    googlepay: ['payment_username'],
                    youtube: ['channel_link'],
                    twitter: ['username'],
                    wechat: ['wechat_number'],
                    threads: ['profile_link'],
                    twitch: ['channel_link'],
                    tiktok: ['username'],
                    snapchat: ['username'],
                    pinterest: ['username'],
                    discord: ['server_link'],
                    telegram: ['telegram_link'],
                    clubhouse: ['username'],
                    calendly: ['url'],
                    reviews: ['contact_number'],
                    etsy: ['username'],
                    applestore: ['username'],
                    chilipiper: ['url'],
                    microsoftbooking: ['username'],
                    booksy: ['username'],
                    square: ['username'],
                    zillow: ['username'],
                    cashapp: ['payment_username'],
                    venmo: ['payment_username'],
                    zelle: ['payment_username'],
                    spotify: ['spotify_link'],
                    applemusic: ['apple_link'],
                    soundcloud: ['music_username'],
                    podcasts: ['music_username'],
                    poshmark: ['username'],
                    mediakits: ['username'],
                    opensea: ['username'],
                    hoobe: ['username'],
                    linktree: ['username'],
                    file: ['username'],
                    customlink: ['username'],
                    // Add mappings for other platforms as needed
                };

                // Set relevant fields based on platform name
                if (platformFields.hasOwnProperty(socialName.toLowerCase())) {
                    const fields = platformFields[socialName.toLowerCase()];
                    fields.forEach((field) => {
                        requestData[field] = todoName; // Assuming todoName contains the value for the field
                    });
                }

                const response = await axiosInstance.post('/SocialLinks/', requestData);
                // window.location.reload(); // Refresh the page without loading

                console.log(response); // Log the response from the server

                onNewItem(todoName, image, link);
            }

            setTodoName('');
            setLink('');
            setError('');
            handleBackClick();
        } catch (error) {
            console.error('Error:', error.message);
            // Handle error if needed
        }
    };

    return (
        <div className="p-6">
            <span className="text-[24px] tracking-wide"> Social Link</span>
            <div className="m-4 flex items-center">
                <div className="flex items-center space-x-2">
                    <img src={image.path} alt={displayName} className="h-12 w-12" />
                    <h1 className="text-lg font-medium capitalize">{image.platform}</h1>
                </div>
            </div>
            <div className="m-4 space-y-2">
                <h2 className="pb-2 text-sm font-normal sm:text-base">{displayName}</h2>
                <input type="text" placeholder={displayName} onChange={handleNameChange} value={todoName} className="form-input h-[45px] w-full" required />

                <h2 className="pb-2 text-sm font-normal sm:text-base">Link</h2>
                <input type="text" placeholder="Link" className="form-input h-[45px] w-full" value={link} onChange={handleLinkChange} required />
            </div>
            {error && <p className="text-red-500">{error}</p>}
            <div className="flex justify-end">
                <button type="button" className="mr-10 underline underline-offset-4" onClick={() => onClose(false)}>
                    Cancel
                </button>
                <button type="button" className="btn btn-primary mx-4 h-[40px] w-[130px] transition duration-300 ease-in-out" onClick={handleAction}>
                    {isEditing ? 'Update' : 'Add Link'}
                </button>
            </div>
        </div>
    );
};

export default SocialContent;
