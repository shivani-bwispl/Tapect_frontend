import Image from 'next/image';
import { useState, useEffect } from 'react';
import tapect_logo from '/public/assets/images/tapect_logo.svg';
import BlankLayout from '@/components/Layouts/BlankLayout';
import { useTranslation } from 'react-i18next';
import axios from 'axios';
import router, { useRouter } from 'next/router';
import axiosInstance from '@/services/api';

const VerifyAccount = () => {
    const handleSubmit = async (e: { preventDefault: () => void }) => {
        e.preventDefault();

        try {
            const response = await axiosInstance.post('/forgotpassword', { email });
            debugger;
            if (response.status === 200 && response.data.success) {
                console.log('Password reset email sent successfully.');
                // Add your success notification or redirection logic here
                router.push('/verifyotp');
            }
        } catch (error) {
            console.error('Error sending password reset email:', error);
            // Add error handling logic here
        }
    };

    return (
        <div>
            <div className="relative box-border flex h-screen min-w-max items-center justify-center bg-white px-6 py-4 sm:px-10">
                <div className="relative w-full max-w-[900px] rounded-md " onSubmit={handleSubmit}>
                    <div className="relative flex flex-col justify-center bg-white">
                        <div className="min-w-screen/30 mx-auto flex flex-col items-center justify-center">
                            <Image src={tapect_logo} width={110} height={110} alt="logo " />
                            <div className="w-30px m-5 text-center">
                                <h1 className="text-lg font-bold !leading-snug text-dark">Verify Account</h1>
                            </div>
                            <form className="min-w-screen/50 w-[400px] space-y-3 rounded-lg border-2 border-solid border-white-light p-9 shadow-3xl dark:text-white">
                                <div className="mb-8">
                                    <span className=" text-xs">Your account is not verified.Please verify your account.</span>
                                </div>
                                <div>
                                    <label htmlFor="OTP" className="font-poppins  font-medium text-dark">
                                        Enter your email
                                    </label>
                                    <input type="text" className="form-input mb-12 border-2 ps-10 focus:border-btnColor-myColor" />
                                </div>
                                <div>
                                    <button type="submit" className="btn !mt-6 w-full border-0 bg-primary uppercase text-white hover:bg-btnColor-myColor">
                                        Continue
                                    </button>
                                </div>
                                <div>
                                    <span className="mt-3">Already have a tapect account?</span>
                                </div>
                            </form>
                            <div className="w-inherit flex items-center justify-evenly space-x-10 p-8 text-sm">
                                <span className="text-screen/1h text-gray">Help</span>
                                <span className="text-screen/1h text-gray">Privacy Policy</span>
                                <span className="text-screen/1h text-gray">Terms</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
VerifyAccount.getLayout = (page: any) => {
    return <BlankLayout>{page}</BlankLayout>;
};
export default VerifyAccount;
