// Import necessary modules and components
import React, { useState, useEffect } from 'react';
import PerfectScrollbar from 'react-perfect-scrollbar';
import { useTranslation } from 'react-i18next';
import { useDispatch, useSelector } from 'react-redux';
import Link from 'next/link';
import Image from 'next/image'; // Import Image component from next/image
import tapect_logo from '../../public/assets/images/tapect_logo.svg';
import UserProfile_logo from '../../public/assets/images/icons/UserProfile_logo.svg';
import More from '../../public/assets/images/icons/More.svg';
import { toggleSidebar } from '../../store/themeConfigSlice';
import { IRootState } from '../../store';
import { useRouter } from 'next/router';
import IconCaretsDown from '@/components/Icon/IconCaretsDown';
import NavItem from './NavItem';
import axiosInstance from '@/services/api'; // Import axiosInstance from your API service

// Define navigation items
const navItems = [
    { name: 'Home', href: '/', isExternal: false },
    { name: 'Profile', href: '/profile', isExternal: false },
    { name: 'Analytics', href: '/analytics', isExternal: false },
    { name: 'Contact', href: '/contact', isExternal: false },
    { name: 'Activate Tag', href: '/activateTag', isExternal: false },
    { name: 'Buy tapect', href: 'https://www.tapect.com/product/', isExternal: true },
    { name: 'tapect For Business', href: 'https://www.tapect.com/for-team-business/', isExternal: true },
    { name: 'Device Compatibility', href: 'https://www.tapect.com/device-compatibility/', isExternal: true },
];
const BottomNavItems = [
    { name: 'Help', href: 'https://www.tapect.com/help/', isExternal: true },
    { name: 'Setting', href: '/setting', isExternal: false },
    { name: 'Logout', href: '#', isExternal: true },
];

// Define Sidebar component
const Sidebar = () => {
    // Initialize necessary hooks and variables
    const router = useRouter();
    const [showOptions, setshowOptions] = useState(false);
    const [userProfiles, setUserProfiles] = useState([]);
    const [activeItem, setActiveItem] = useState(null);
    const handleMoreClick = () => {
        setshowOptions(!showOptions);
    };

    // Fetch user profile data when component mounts
    useEffect(() => {
        const fetchUserProfile = async () => {
            try {
                const userId = localStorage.getItem('userId');
                if (!userId) {
                    throw new Error('User ID not found in localStorage');
                }
                const response = await axiosInstance.get(`/profileUpdate/${userId}`);
                const userProfileData = response.data;
                setUserProfiles([userProfileData]); // Assuming response.data is an object
            } catch (error) {
                console.error('Error fetching user profile:', error.message);
                setUserProfiles([]); // Reset user profile state to an empty array or set a default value
            }
        };
        fetchUserProfile(); // Call fetchUserProfile when the component mounts
    }, []);

    // Set active route when component mounts
    useEffect(() => {
        setActiveRoute();
    }, []);

    // Set active route based on router pathname
    const setActiveRoute = () => {
        const currentPath = router.pathname;
        setActiveItem(currentPath);
        const selector = document.querySelector('.sidebar ul a[href="' + window.location.pathname + '"]');
        if (selector) {
            selector.classList.add('active');
            const ul = selector.closest('ul.sub-menu');
            if (ul) {
                let ele = ul.closest('li.menu').querySelectorAll('.nav-link')[0];
                if (ele) {
                    setTimeout(() => {
                        ele.click();
                    });
                }
            }
        }
    };

    // Logout handler
    const handleLogout = () => {
        localStorage.removeItem('token'); // Clear authentication state
        localStorage.removeItem('userId'); // Clear authentication state

        localStorage.removeItem('isLoggedIn'); // Clear authentication state
        router.push('/Login'); // Redirect to the login page after logout
    };

    // Navigation item click handler
    const handleNavItemClick = (itemName, href, isExternal, event) => {
        if (event) {
            event.preventDefault();
            event.stopPropagation();
        }
        setActiveItem(itemName);
        if (!isExternal) {
            setActiveItem(href);
            router.push(href);
        } else {
            window.open(href, '_blank');
        }
    };

    // Render Sidebar component
    return (
        <div>
            <nav className={`sidebar fixed bottom-0 top-0 z-50 h-full min-h-screen w-[260px] `}>
                <div className="h-full bg-white dark:bg-black">
                    <div className="flex items-center justify-center px-4 py-3">
                        <Link href="/" className="main-logo flex items-center justify-center">
                            <Image className="w-15 ml-[5px] w-[65%]" src={tapect_logo} alt="logo" height={65} width={54} />
                        </Link>
                    </div>
                    <PerfectScrollbar className="relative h-[calc(100vh-80px)]">
                        <div className="flex  h-full flex-col justify-between">
                            <div>
                                <ul className="relative p-4 py-0 font-semibold">
                                    {navItems.map((item) => (
                                        <NavItem
                                            key={item.name}
                                            name={item.name}
                                            href={item.href}
                                            isExternal={item.isExternal}
                                            isActive={activeItem === item.href}
                                            onClick={item.name === 'Logout' ? handleLogout : () => handleNavItemClick(item.name, item.href, item.isExternal)}
                                        />
                                    ))}
                                </ul>
                            </div>
                            <div className="flex h-fit w-full cursor-pointer items-center justify-between border-t-2 px-2  py-3" onClick={handleMoreClick}>
                                {userProfiles.map((userProfilesData) => (
                                    <React.Fragment key={userProfilesData}>
                                        <div className="flex items-center justify-center gap-2 ">
                                            <Image src={UserProfile_logo} width={40} height={40} alt="userprofile_logo"></Image>
                                            <span className="text-md font-semibold text-gray">{`${userProfilesData['first_name']} ${userProfilesData['last_name']}`}</span>
                                        </div>
                                    </React.Fragment>
                                ))}
                                <Image src={More} width={3} height={3} alt="more"></Image>
                                {showOptions && (
                                    <div className=" absolute bottom-20  w-[90%]  rounded-lg border bg-white py-2">
                                        <ul className="relative   font-semibold">
                                            {BottomNavItems.map((item) => (
                                                <NavItem
                                                    key={item.name}
                                                    name={item.name}
                                                    href={item.href}
                                                    isExternal={item.isExternal}
                                                    isActive={activeItem === item.href}
                                                    onClick={item.name === 'Logout' ? handleLogout : () => handleNavItemClick(item.name, item.href, item.isExternal)}
                                                />
                                            ))}
                                        </ul>
                                    </div>
                                )}
                            </div>
                        </div>
                    </PerfectScrollbar>
                </div>
            </nav>
        </div>
    );
};

export default Sidebar;
