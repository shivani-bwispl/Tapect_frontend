const Footer = () => {
    return <div className="text-md m-5 text-center font-thin dark:text-white-dark ltr:sm:text-center rtl:sm:text-center ">© {new Date().getFullYear()}. Tapect All Rights are Reserved </div>;
};

export default Footer;
