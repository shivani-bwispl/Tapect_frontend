
function Loader() {
    return (
        <div className="text-center mt-10">
            <span className="animate-spin border-4 border-primary border-l-transparent rounded-full w-10 h-10 inline-block align-middle"> </span>
            </div>
            );
}

export default Loader;