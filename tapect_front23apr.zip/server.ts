// const express = require('express');
// const bodyParser = require('body-parser');
// import connectMongoDB from "../Tapect-main/data_api/config";
// import RegisterUser from "../Tapect-main/data_api/models/register";
// import login from '../Tapect-main/pages/api/login';
// const otpVerifyRoute = require('./routes/otpVerify');
// const userProfileUpdate = require('./routes/profileUpdate');
// const getUser = require('./routes/getUser');

// var http = require('http');

// var server = http.createServer(function(req:any, res:any) {
//   res.writeHead(200);
//   res.end('hey');
// }).listen(process.env.PORT || 8000, function() {
//   console.log('App listening on port %d', server.address().port);
// });