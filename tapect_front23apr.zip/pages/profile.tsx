import { NextLink } from 'next/link'; // Import NextLink from next/link
import Link from 'next/link'; // Import Link from next/link

import { Fragment, SetStateAction, useEffect, useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { useDispatch, useSelector } from 'react-redux';
import { IRootState } from '../store';
import { Tab } from '@headlessui/react';
import FileUpload from './FileUpload';
import CustomCard from './CustomCard';
import About from './About';
import Loader from '../components/Loader';
import { useForm } from 'react-hook-form';
import LeadCapture from './LeadCapture';
import SocialLinks from './SocialLinks';
import CompanyInfo from './CompanyInfo';

// import MoreLinks from './MoreLinks';
import Notes from './Notes';
import { ImageProvider } from '../components/ImageContext';
import ColorPicker from './ColorPicker';
import TapCode from './TapCode';
import Setting from './setting';
import { useColorContext } from '../components/ColorContext';
import { ColorProvider } from '../components/ColorContext';
import ColorPalette from './ColorPalette';
import { setPageTitle } from '@/store/themeConfigSlice';
import router, { useRouter } from 'next/router';
import axios from 'axios';
import ErrorDisplay from '../components/ErrorDisplay';
import sweetAService from '../services/sweetAlertService';
import { LeadCaptureProvider } from '../components/LeadCaptureContext';
//? socialLinks
import Image from 'next/image';
import Delete from '../public/assets/images/icons/Delete.svg';
//?

//? MoreLinks
import CustomLink from '../public/assets/images/icons/customlink.svg';
import File from '../public/assets/images/icons/File.svg';
import QuickLink_Modal from './QuickLink_Modal';
import axiosInstance from '@/services/api';
//?

const Profile = () => {
    const {
        register,
        handleSubmit,
        control,
        formState: { errors },
    } = useForm();

    const router = useRouter();
    const dispatch = useDispatch();
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [error, setError] = useState(null);
    const [users, setUsers] = useState([]);
    const [viewCardUrl, setViewCardUrl] = useState([FormData]);

    // //? social Links
    const [showModal, setShowModal] = useState(false);
    const [selectedSocial, setSelectedSocial] = useState(null);
    const [showContent, setShowContent] = useState(false);

    //? Tabs
    const [hoveredTab, setHoveredTab] = useState(null);

    const handleMouseEnter = (tabIndex) => {
        setHoveredTab(tabIndex);
    };

    const handleMouseLeave = () => {
        setHoveredTab(null);
    };

    const tabData = [
        { icon: 'Mycard', label: 'My Card', alt: 'home' },
        { icon: 'Social', label: 'Social Links', alt: 'social' },
        // { icon: 'Links', label: 'Links', alt: 'links' },
        { icon: 'CompanyInfo', label: 'Company Info', alt: 'company info' },
        { icon: 'Customize', label: 'Customize Theme', alt: 'customize' },
        { icon: 'TapCode', label: 'Tap Code', alt: 'tap code' },
        { icon: 'LeadForm', label: 'Lead Capture Form', alt: 'lead form' },
    ];

    //? todo
    const [SocialItems, setSocialItems] = useState([]);

    //? selected Todo
    const [SelectedSocialItem, setSelectedSocialItem] = useState(null);

    const handleNewItem = (itemName, image, link) => {
        const newSocialItem = {
            id: Math.floor(Math.random() * 100000),
            image: image,
            name: itemName,
            link: link,
        };
        const updatedSocialItems = [...SocialItems, newSocialItem];
        setSocialItems(updatedSocialItems);
    };

    const updateSocialItem = (id, name, link) => {
        setSocialItems((prevItems) => {
            return prevItems.map((item) => {
                if (item.id === id) {
                    return { ...item, name, link };
                }
                return item;
            });
        });
    };

    const DeleteEle = (id) => {
        const updatedSocialItems = SocialItems.filter((item) => item.id !== id);
        setSocialItems(updatedSocialItems);
    };

    const handleEdit = (id) => {
        const ele = SocialItems.find((SocialItem) => SocialItem.id === id);
        console.log(ele);

        setSelectedSocialItem(ele);
        setShowModal(true);
        setShowContent(true);
    };

    interface FormData {
        first_name: string;
        last_name: string;
        organization_name: string;
        job_title: string;
        email: string;
        phone_number: string;
        profile_email: string;
        company_name: string;
        company_contact: string;
        street_address: string;
        city: string;
        state: string;
        country: string;
        post_code: string;
        website: string;
        note: string;
        bgcolor: string;
        LinkTitle: string;
        FileTitle: string;
    }

    const [formData, setFormData] = useState<FormData>({
        first_name: '',
        last_name: '',
        organization_name: '',
        job_title: '',
        email: '',
        phone_number: '',
        profile_email: '',
        company_name: '',
        company_contact: '',
        street_address: '',
        city: '',
        state: '',
        country: '',
        post_code: '',
        website: '',
        note: '',
        bgcolor: '',
        LinkTitle: '',
        FileTitle: '',
    });

    // Handler to update form data
    const handleFormChange = (newFormData: SetStateAction<FormData>) => {
        setFormData(newFormData);
    };

    const [remainingChars, setRemainingChars] = useState(250);
    const maxChars = 250;

    const handleInputChange = (e: any) => {
        const { name, value } = e.target;

        if (value.length <= maxChars) {
            handleFormChange({
                ...formData,
                [name]: value,
            });
            setRemainingChars(maxChars - value.length);
        }

        if (value.length === maxChars) {
            // Display alert when character count reaches 250
            alert('Maximum character limit reached (250 characters)');
        }
    };

    useEffect(() => {
        dispatch(setPageTitle('Profile'));
        // Check if the user is authenticated

        const isLoggedIn = localStorage.getItem('isLoggedIn');

        if (!isLoggedIn) {
            // Redirect to the login page if not authenticated
            router.replace('/Login');
        }
    }, [dispatch]);

    // UseEffect to fetch user profile data
    useEffect(() => {
        const fetchUserProfile = async () => {
            try {
                const userId = localStorage.getItem('userId');
                if (!userId) {
                    throw new Error('User ID not found in localStorage');
                }
                const response = await axiosInstance.get(`/profileUpdate/${userId}`);
                const userProfileData = response.data;
                const { tags } = userProfileData || {}; // Extracting only the 'tags' field from userProfileData, handling the case where userProfileData is undefined

                let tagsArray = Array.isArray(tags) ? tags : [tags]; // Convert tags to array if it's not already
                const tagsUrl = encodeURIComponent(tagsArray.join(',')); // Encode tags array to be used in URL
                setViewCardUrl(`/ViewCard?tags=${tagsUrl}`); // Constructing URL with tags data
            } catch (error) {
                console.error('Error fetching user profile:', error.message); // corrected 'errors' to 'error'
                setViewCardUrl('/ViewCard'); // Reset user profile state to the default ViewCard URL
            }
        };

        fetchUserProfile(); // Call fetchUserProfile when the component mounts
    }, []);

    const { backgroundColor, textColor, buttonColor, buttonTextColor, updateBackgroundColor, updateTextColor, updateButtonColor, updateButtonTextColor } = useColorContext();

    const [loading, setLoading] = useState(false);

    return (
        <>
            <ImageProvider>
                <ColorProvider>
                    <LeadCaptureProvider>
                        <div className=" mb-5 grid grid-cols-1 overflow-y-auto px-5 pt-2 lg:grid-cols-4  ">
                            <div className="panel  rounded-tl-lg lg:col-span-3  ">
                                <div className="mb-5 ">
                                    <div id="border_top">
                                        <div className="mb-5">
                                            <Tab.Group>
                                                <Tab.List className="mt-3 flex flex-wrap gap-x-5 border-b border-white-light px-2 dark:border-[#191E3A]">
                                                    {tabData.map((tab, index) => (
                                                        <Tab key={index} as={Fragment}>
                                                            {({ selected }) => (
                                                                <div
                                                                    className={`ml-${index > 0 ? 2 : 0} ${
                                                                        selected ? 'border-b !border-secondary text-secondary !outline-none' : ''
                                                                    } flex items-center hover:border-b hover:!border-secondary hover:text-secondary`}
                                                                    onMouseEnter={() => handleMouseEnter(index)}
                                                                    onMouseLeave={handleMouseLeave}
                                                                >
                                                                    <Image
                                                                        alt={tab.alt}
                                                                        width={16}
                                                                        height={16}
                                                                        src={`/assets/images/icons/${tab.icon}-${selected || hoveredTab === index ? 'hover' : 'default'}.svg`}
                                                                    />
                                                                    <button className={` flex items-center border-transparent p-2 py-2`}>{tab.label}</button>
                                                                </div>
                                                            )}
                                                        </Tab>
                                                    ))}
                                                </Tab.List>

                                                <Tab.Panels>
                                                    <Tab.Panel>
                                                        <div className="active h-[calc(100vh-5rem)] overflow-y-auto pt-5">
                                                            <FileUpload></FileUpload>
                                                            <About formData={formData} handleInputChange={handleInputChange}></About>
                                                        </div>
                                                    </Tab.Panel>
                                                    <Tab.Panel>
                                                        <SocialLinks
                                                            showModal={showModal}
                                                            setShowModal={setShowModal}
                                                            handleNewItem={handleNewItem}
                                                            updateSocialItem={updateSocialItem}
                                                            SocialItems={SocialItems}
                                                            DeleteEle={DeleteEle}
                                                            formData={formData}
                                                            onChange={handleInputChange}
                                                            handleEdit={handleEdit}
                                                            SelectedSocialItem={SelectedSocialItem}
                                                            selectedSocial={selectedSocial}
                                                            setSelectedSocial={setSelectedSocial}
                                                            showContent={showContent}
                                                            setShowContent={setShowContent}
                                                        ></SocialLinks>
                                                    </Tab.Panel>

                                                    <Tab.Panel>
                                                        <CompanyInfo formData={formData} handleInputChange={handleInputChange}></CompanyInfo>
                                                    </Tab.Panel>
                                                    <Tab.Panel>
                                                        <div className=" h-[calc(100vh-5rem)] overflow-y-auto">
                                                            <ColorPalette />
                                                            <div className="grid grid-cols-2 justify-items-center">
                                                                <ColorPicker category="backgroundColor" label="Background Color" onChange={updateBackgroundColor} />
                                                                <ColorPicker category="textColor" label="Text Color" onChange={updateTextColor} />
                                                                <ColorPicker category="buttonColor" label="Button Color" onChange={updateButtonColor} />
                                                                <ColorPicker category="buttontextColor" label="Button Text" onChange={updateButtonTextColor} />
                                                            </div>
                                                        </div>
                                                    </Tab.Panel>
                                                    <Tab.Panel>
                                                        <TapCode />
                                                    </Tab.Panel>
                                                    <Tab.Panel>
                                                        <LeadCapture />
                                                    </Tab.Panel>
                                                </Tab.Panels>
                                            </Tab.Group>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="panel min-h-screen w-full rounded-tl-lg max-lg:min-w-60 lg:w-72">
                                <div className="mb-5 flex flex-col items-center justify-start gap-2">
                                    <h5 className="text-lg font-semibold dark:text-white-light">Card live preview</h5>

                                    {viewCardUrl && (
                                        <Link href={viewCardUrl} target="_blank" rel="noopener noreferrer">
                                            <div className="cursor-pointer text-primary underline">View Card</div>
                                        </Link>
                                    )}
                                </div>
                                <div className="my-3 flex flex-shrink-0  items-center justify-center  max-md:min-w-60">
                                    <CustomCard formData={formData} SocialItems={SocialItems} />
                                </div>
                            </div>
                        </div>
                    </LeadCaptureProvider>
                </ColorProvider>
            </ImageProvider>
        </>
    );
};

export default Profile;
