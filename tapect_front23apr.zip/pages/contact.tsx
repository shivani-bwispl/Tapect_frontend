/* eslint-disable react/jsx-key */
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useTable, useSortBy, usePagination, useRowSelect } from 'react-table';
import More from '../public/assets/images/icons/More.svg';
import Export from '../public/assets/images/icons/Export.svg';
import Image from 'next/image';
import Dropdown from '../components/Dropdown';
import { useRouter } from 'next/router';
import EditContact from './EditContact';
import axiosInstance from '@/services/api';

const Contact = () => {
    const router = useRouter();
    const [contactData, setContactData] = useState([]);
    const [selectedOption, setSelectedOption] = useState([]);
    const [activeRow, setActiveRow] = useState(null); // Track the active row
    const options = ['Sort Full Name', 'Sort Date Wise'];
    const [ModalOpen, setModalOpen] = useState(false);
    const [selectedContactId, setSelectedContactId] = useState(null);

    const openModal = (contactId) => {
        setSelectedContactId(contactId === activeRow ? null : contactId);
        setModalOpen(true);
    };

    const closeModal = () => {
        setModalOpen(false);
    };

    const handleSelect = (selectedOption) => {
        console.log('Selected option:', selectedOption);
        setSelectedOption(selectedOption);
    };

    useEffect(() => {
        const fetchContactData = async () => {
            try {
                const userId = localStorage.getItem('userId');
                if (!userId) {
                    throw new Error('User ID not found in localStorage');
                }
                const response = await axiosInstance.get(`/contact_details/${userId}`);
                // Format the date before setting the state
                const formattedContactData = response.data.userContact.map((contact) => ({
                    ...contact,
                    created_at: new Date(contact.created_at).toISOString().slice(0, 10), // Format to yyyy-mm-dd
                }));
                console.log(formattedContactData, 'contactId');

                setContactData(formattedContactData);
            } catch (error) {
                console.error('Error fetching contact data:', error);
            }
        };
        fetchContactData();
    }, []);

    const handleContactClick = (event, contact) => {
        // Check if the target element is the checkbox
        if (event.target.type !== 'checkbox') {
            const encodedContact = btoa(JSON.stringify(contact)); // Encode contact details
            router.push({
                pathname: `/contact/${contact._id}`,
                query: { data: encodedContact }, // Pass encoded contact data in the query
            });
        }
    };

    const handleMoreClick = (event, contactId) => {
        event.stopPropagation(); // Prevent the row click event from triggering
        // Set the active row
        setActiveRow(contactId === activeRow ? null : contactId);
        // Pass the contact ID to open the modal with the corresponding contact data
        // openModal(contactId);
    };

    const removeContact = async (contactId) => {
        try {
            const response = await axiosInstance.delete(`/contact_details/${contactId}`);
            console.log(response.data, 'response.data');
            return response.data; // Return the response data
        } catch (error) {
            throw new Error(`Error removing contact: ${error.message}`);
        }
    };

    const handleRemoveContact = async (contactId) => {
        try {
            // Call removeContact function with contactId
            await removeContact(contactId);
            // Remove the contact from the state after successful deletion
            setContactData(contactData.filter((contact) => contact._id !== contactId));
        } catch (error) {
            console.error('Error removing contact:', error);
        }
    };

    // --------------------generate vcf file-----------------------

    const generateVCF = (contact) => {
        const vcard = `BEGIN:VCARD
VERSION:3.0
FN:${contact.fullname}
ORG:${contact.company}
TEL;TYPE=WORK,VOICE:${contact.contact_phonenumber}
EMAIL;TYPE=PREF,INTERNET:${contact.contact_email}
URL:${contact.website}
END:VCARD`;

        return vcard;
    };

    const saveAsContact = (contactData) => {
        // Convert contact data to VCF format string
        const vcfString = generateVCF(contactData);

        // Create a blob with the VCF content
        const blob = new Blob([vcfString], { type: 'text/vcard' });

        // Create a URL for the blob
        const url = URL.createObjectURL(blob);

        // Create a link element
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'contacts.vcf'); // Set filename

        // Simulate click on the link to trigger download
        document.body.appendChild(link);
        link.click();

        // Clean up
        URL.revokeObjectURL(url);
        document.body.removeChild(link);
    };

    const handleSaveAsContact = (contactId) => {
        try {
            const contact = contactData.find((contact) => contact._id === contactId);
            if (!contact) {
                throw new Error('Contact not found');
            }
            saveAsContact(contact);
        } catch (error) {
            console.error('Error saving contact as VCF:', error);
        }
    };

    const columns = React.useMemo(
        () => [
            {
                id: 'selection',
                Header: ({ getToggleAllRowsSelectedProps }) => (
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                        <input type="checkbox" {...getToggleAllRowsSelectedProps()} style={{ marginRight: '8px', verticalAlign: 'middle' }} />
                    </div>
                ),
                Cell: ({ row }) => (
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                        <input type="checkbox" {...row.getToggleRowSelectedProps()} style={{ marginRight: '8px', verticalAlign: 'middle' }} />
                        <img src="../assets/images/icons/ProfileIcon.svg" alt="profile" className="mx-auto h-10 w-10 rounded-full" />
                    </div>
                ),
            },

            {
                Header: 'Full Name',
                accessor: 'fullname',
            },
            {
                Header: 'Connected with',
                accessor: 'connected_with',
                Cell: ({ row }) => <img src="../assets/images/icons/ProfileIcon.svg" alt="connectedWith" className="mx-auto h-10 w-10 rounded-full" />,
            },
            {
                Header: 'Date',
                accessor: 'created_at',
            },
            {
                Header: '',
                accessor: 'Export',
                disableFilters: true,
                disableSortBy: true,
                Cell: ({ row }) => (
                    <div className="flex items-center justify-center">
                        <Image src={Export} alt="Export" width={15} height={15} />
                    </div>
                ),
            },
            {
                Header: '',
                accessor: 'more',
                disableFilters: true,
                disableSortBy: true,
                Cell: ({ row }) => (
                    <div className="options-cell flex items-center justify-center" style={{ position: 'relative' }}>
                        <Image src={More} alt="more" width={3} height={3} onClick={(e) => handleMoreClick(e, row.original.id)} className="cursor-pointer" />
                        {activeRow === row.original.id && (
                            <div className="absolute z-30 mb-5 w-fit min-w-[12vw] bg-white" style={{ position: 'absolute', top: '100%', right: '50%' }}>
                                <div className="flex flex-col rounded-md border border-white-light font-semibold dark:border-[#1B2E4B]">
                                    <button
                                        className="border-b border-white-light px-4 py-2.5 hover:bg-[#F5EFFF] dark:border-[#1B2E4B] dark:hover:bg-[#eee]/10"
                                        onClick={(e) => handleContactClick(e, row.original)}
                                    >
                                        View Connection
                                    </button>
                                    <button
                                        className="border-b border-white-light px-4 py-2.5 hover:bg-[#F5EFFF] dark:border-[#1B2E4B] dark:hover:bg-[#eee]/10"
                                        onClick={() => openModal(row.original._id)}
                                    >
                                        Edit Connection
                                    </button>
                                    <button
                                        className="border-b border-white-light px-4 py-2.5 hover:bg-[#F5EFFF] dark:border-[#1B2E4B] dark:hover:bg-[#eee]/10"
                                        onClick={() => handleSaveAsContact(row.original._id)}
                                    >
                                        Save as Contact
                                    </button>
                                    <div>
                                        <button
                                            className="border-b border-white-light px-4 py-2.5 hover:bg-[#F5EFFF] dark:border-[#1B2E4B] dark:hover:bg-[#eee]/10"
                                            onClick={() => handleRemoveContact(row.original._id)}
                                        >
                                            Remove
                                        </button>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                ),
            },
        ],
        [activeRow] // Update dependency array
    );

    const tableInstance = useTable(
        {
            columns,
            data: contactData,
            initialState: { pageSize: 10 },
        },
        useSortBy,
        usePagination,
        useRowSelect
    );

    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        page,
        prepareRow,
        nextPage,
        previousPage,
        canPreviousPage,
        canNextPage,
        state: { pageIndex },
        pageCount,
        gotoPage,
        pageOptions,
        pageSize,
        setPageSize,
    } = tableInstance;

    return (
        <div className="h-screen overflow-y-auto px-5 py-3">
            <table {...getTableProps()} className="w-full border-collapse border border-gray-200">
                <thead className="bg-gray-200">
                    {headerGroups.map((headerGroup) => (
                        <tr {...headerGroup.getHeaderGroupProps()}>
                            {headerGroup.headers.map((column) => (
                                <th {...column.getHeaderProps(column.getSortByToggleProps())}>
                                    {column.render('Header')}
                                    {column.isSorted && <span> {column.isSortedDesc ? '⬇️' : '⬆️'}</span>}
                                </th>
                            ))}
                        </tr>
                    ))}
                </thead>
                <tbody {...getTableBodyProps()}>
                    {page.map((row, rowIndex) => {
                        prepareRow(row);
                        return (
                            <tr {...row.getRowProps()} className={`${rowIndex % 2 === 0 ? 'bg-gray-100' : 'bg-white'} border-b border-gray-200`}>
                                {row.cells.map((cell, index) => (
                                    <td {...cell.getCellProps()} className={`px-8 py-2 ${index === row.cells.length - 1 ? 'pr-0' : ''}`}>
                                        {cell.render('Cell')}
                                    </td>
                                ))}
                            </tr>
                        );
                    })}
                </tbody>
            </table>
            <div className="btn-container">
                <button disabled={pageIndex === 0} onClick={() => gotoPage(0)}>
                    First
                </button>
                <button disabled={!canPreviousPage} onClick={previousPage}>
                    Prev
                </button>
                <span>
                    {pageIndex + 1} of {pageCount}
                </span>
                <button disabled={!canNextPage} onClick={nextPage}>
                    Next
                </button>
                <button disabled={pageIndex >= pageCount - 1} onClick={() => gotoPage(pageCount - 1)}>
                    {' '}
                    last
                </button>
            </div>
            <EditContact isOpen={ModalOpen} onClose={closeModal} contactId={selectedContactId}></EditContact>
        </div>
    );
};

export default Contact;
