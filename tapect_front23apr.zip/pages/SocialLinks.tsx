import React from 'react';
import Image from 'next/image';
import Modal from './Modal';
import SocialLinkLists from './SocialLinkLists';
import { useState } from 'react';
import back_design from '../public/assets/images/icons/back_design.svg';

const SocialLinks = ({ selectedSocial, showContent, setShowContent, showModal, setShowModal, handleNewItem, SocialItems, DeleteEle, formData, setSelectedSocial, updateSocialItem }) => {
    // const [showModal, setShowModal] = useState(false);
    const [SelectedSocialItem, setSelectedSocialItem] = useState([]);
    const [SelectedSocialId, setSelectedSocialId] = useState(null);

    const handleButtonClick = () => {
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
    };

    return (
        <>
            <div className="flex  h-[calc(100vh-5rem)]  flex-col justify-between overflow-y-auto bg-contentPage ">
                <div>
                    <div className="flex items-center justify-center">
                        <div className="flex w-full  items-center justify-between p-5 ">
                            <span className="text-md  font-bold">Social Links</span>
                            <button type="button" className="btn btn-primary xl:w-55  sm:w-24 md:w-32 lg:w-44" onClick={handleButtonClick}>
                                +Add Social Links
                            </button>
                        </div>
                    </div>
                    <SocialLinkLists
                        setShowContent={setShowContent}
                        setShowModal={setShowModal}
                        SocialItems={SocialItems}
                        DeleteEle={DeleteEle}
                        SelectedSocialItem={SelectedSocialItem}
                        setSelectedSocialItem={setSelectedSocialItem}
                        setSelectedSocialId={setSelectedSocialId}
                        SelectedSocialId={SelectedSocialId}
                    ></SocialLinkLists>
                    {/* <WelcomeMsg SocialItems={SocialItems} /> */}
                </div>
                <Modal
                    isOpen={showModal}
                    onClose={setShowModal}
                    onNewItem={handleNewItem}
                    onUpdateItem={updateSocialItem}
                    formData={formData}
                    DeleteEle={DeleteEle}
                    SelectedSocialItem={SelectedSocialItem}
                    selectedSocial={selectedSocial}
                    showContent={showContent}
                    setShowContent={setShowContent}
                    setSelectedSocial={setSelectedSocial}
                ></Modal>
            </div>
        </>
    );
};

export default SocialLinks;
