import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import axios from 'axios';
import Delete from '../public/assets/images/icons/Delete.svg';
import EditLink from '../public/assets/images/icons/EditLink.svg';
import { useRouter } from 'next/dist/client/router';
import EditSocial from '../pages/EditSocial';
import axiosInstance from '../services/api';

const SocialLinkLists = ({ selectedSocial, SocialItems, DeleteEle, setShowModal, setShowContent, setSelectedSocialItem, SelectedSocialItem, setSelectedSocialId, SelectedSocialId }) => {
    const router = useRouter();

    const [socialLinks, setSocialLinks] = useState([]);
    const [error, setError] = useState(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [successMessage, setSuccessMessage] = useState(null); // State variable for success message

    const closeModal = () => {
        setIsModalOpen(false);
    };
    const openModal = () => {
        setIsModalOpen(true);
    };

    console.log(socialLinks);

    const handleEditItem = async (id, type, itemData) => {
        // const ele = socialLinks.find((socialLink) => socialLink.id === id);
        // console.log(ele);
        // setSelectedSocialItem(ele);
        try {
            // Use itemData to prefill the modal or perform any other operations

            // setShowModal(true);
            // setShowContent(true);
            setIsModalOpen(true);
            setSelectedSocialId(id);

            setSelectedSocialItem(itemData);
            // Open the modal or perform any other action
            console.log('Edit button clicked for item:', itemData);
            console.log('Edit button clicked for item:', id);
            console.log('Edit button clicked for item:', type);
        } catch (error) {
            console.error('Error editing item:', error.message);
        }
    };

    const handleDeleteItem = async (id, type) => {
        try {
            const userId = localStorage.getItem('userId');
            if (!userId) {
                throw new Error('User ID not found in localStorage');
            }

            const response = await axiosInstance.delete(`/SocialLinks/`, {
                data: {
                    userId: userId,
                    [`${type}Id`]: id,
                },
            });

            setSuccessMessage('Social link deleted successfully');

            setTimeout(() => {
                setSuccessMessage(null); // Remove success message after 10 seconds
            }, 10000); // 10 seconds in milliseconds

            // DeleteEle(id);
            router.reload();
        } catch (error) {
            console.error('Error deleting social link:', error.message);
        }
    };

    useEffect(() => {
        const fetchUserSocialLinks = async () => {
            try {
                const userId = localStorage.getItem('userId');
                if (!userId) {
                    throw new Error('User ID not found in localStorage');
                }
                const response = await axios.get(`http://localhost:3001/api/SocialLinks/${userId}`);
                const responseData = response.data;
                console.log(responseData, 'responseData');
                if (responseData.existingSocialLink) {
                    setSocialLinks(responseData.existingSocialLink);
                } else {
                    setError('Social links not found for this user');
                }
            } catch (error) {
                console.error('Error fetching user social links:', error.message);
                setSocialLinks([]); // Reset social links state to an empty array
            }
        };

        fetchUserSocialLinks(); // Call fetchUserSocialLinks when the component mounts
    }, []);

    return (
        <div className="container mx-auto">
            {error && <p className="text-red-500">Error: {error}</p>}
            {successMessage && <p className="text-green-500">{successMessage}</p>}

            <div>
                <h2 className="text-2xl font-bold">User Social Links</h2>
                {socialLinks && (
                    <div>
                        <h3 className="ml-2 mt-4 text-xl font-semibold">Social Media</h3>
                        <ul className="ml-2 list-disc">
                            {socialLinks.Social_Media &&
                                socialLinks.Social_Media.map((media) => (
                                    <li key={media._id} className="mb-2 mt-3 flex h-[55px] w-full items-center justify-between rounded-lg bg-purple-Light px-3">
                                        <div className="flex items-center justify-center">
                                            {media.image && <Image src={media.image} width={25} height={25} alt={media} />}
                                            {/* <span className="ml-2 font-normal">{media.linktitle}</span> */}
                                            <br></br>
                                            <span className="ml-2 font-normal">{media.username && `${media.username}`}</span>

                                            <span className="ml-2 font-normal">{media.profile_link && `${media.profile_link}`}</span>
                                            <span className="ml-2 font-normal">{media.channel_link && `${media.channel_link}`}</span>
                                            <span className="ml-2 font-normal">{media.server_link && ` ${media.server_link}`}</span>
                                            <span className="ml-2 font-normal">{media.telegram_link && `${media.telegram_link}`}</span>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <button className="focus:outline-none" type="button" onClick={() => handleEditItem(media._id, 'socialMedia', media)}>
                                                <Image src={EditLink} width={20} height={20} alt="Edit" />
                                            </button>
                                            <button className="focus:outline-none" type="button" onClick={() => handleDeleteItem(media._id, 'socialMedia')}>
                                                <Image src={Delete} width={15} height={15} alt="Delete" />
                                            </button>
                                        </div>
                                    </li>
                                ))}
                        </ul>

                        <h3 className="ml-2 mt-4 text-xl font-semibold">Business Info</h3>
                        <ul className="ml-2 list-disc">
                            {socialLinks.Business &&
                                socialLinks.Business.map((business) => (
                                    <li key={business._id} className="mb-2 mt-3 flex h-[55px] w-full items-center justify-between rounded-lg bg-purple-Light  px-3">
                                        <div className="flex items-center justify-center">
                                            {business.image && <Image src={business.image} width={25} height={25} alt={business} />}
                                            {/* <span className="ml-2 font-normal">{business.linktitle}</span> */}
                                            <span className="ml-2 font-normal">{business.contact_number && `${business.contact_number}`}</span>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <button className="focus:outline-none" type="button" onClick={() => handleEditItem(business._id, 'business', business)}>
                                                <Image src={EditLink} width={20} height={20} alt="Edit" />
                                            </button>
                                            <button className="focus:outline-none" type="button" onClick={() => handleDeleteItem(business._id, 'business')}>
                                                <Image src={Delete} width={15} height={15} alt="Delete" />
                                            </button>
                                        </div>
                                    </li>
                                ))}
                        </ul>

                        <h3 className="ml-2 mt-4 text-xl font-semibold">Contact Info</h3>

                        <ul className="ml-2 list-disc">
                            {socialLinks.Contact &&
                                socialLinks.Contact.map((contact) => (
                                    <li key={contact._id} className="mb-2 mt-3 flex h-[55px] w-full items-center justify-between rounded-lg bg-purple-Light  px-3">
                                        <div className="flex items-center justify-center">
                                            {contact.image && <Image src={contact.image} width={25} height={25} alt={contact} />}
                                            {/* <span className="ml-2 font-normal">{contact.linktitle}</span> */}

                                            <span className="ml-2 font-normal">{contact.phone_number && `${contact.phone_number}`}</span>
                                            <span className="ml-2 font-normal">{contact.whatsapp_number && `${contact.whatsapp_number}`}</span>

                                            <span className="ml-2 font-normal">{contact.email_address && `${contact.email_address}`}</span>

                                            <span className="ml-2 font-normal">{contact.business_address && `${contact.business_address}`}</span>
                                            <span className="ml-2 font-normal">{contact.facetime && `${contact.facetime}`}</span>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <button className="focus:outline-none" type="button" onClick={() => handleEditItem(contact._id, 'contact', contact)}>
                                                <Image src={EditLink} width={20} height={20} alt="Edit" />
                                            </button>
                                            <button className="focus:outline-none" type="button" onClick={() => handleDeleteItem(contact._id, 'contact')}>
                                                <Image src={Delete} width={15} height={15} alt="Delete" />
                                            </button>
                                        </div>
                                    </li>
                                ))}
                        </ul>

                        <h3 className="ml-2 mt-4 text-xl font-semibold">Payment Info</h3>

                        <ul className="ml-2 list-disc">
                            {socialLinks.Payment &&
                                socialLinks.Payment.map((payment) => (
                                    <li key={payment._id} className="mb-2 mt-3 flex h-[55px] w-full items-center justify-between rounded-lg bg-purple-Light  px-3">
                                        <div className="flex items-center justify-center">
                                            {payment.image && <Image src={payment.image} width={25} height={25} alt={payment} />}
                                            {/* <span className="ml-2 font-normal">{payment.linktitle}</span> */}

                                            <span className="ml-2 font-normal">{payment.paypal_link && `${payment.paypal_link}`}</span>
                                            <span className="ml-2 font-normal">{payment.payment_username && `${payment.payment_username}`}</span>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <button className="focus:outline-none" type="button" onClick={() => handleEditItem(payment._id, 'payment', payment)}>
                                                <Image src={EditLink} width={20} height={20} alt="Edit" />
                                            </button>
                                            <button className="focus:outline-none" type="button" onClick={() => handleDeleteItem(payment._id, 'payment')}>
                                                <Image src={Delete} width={15} height={15} alt="Delete" />
                                            </button>
                                        </div>
                                    </li>
                                ))}
                        </ul>

                        <h3 className="ml-2 mt-4 text-xl font-semibold">Music Info</h3>

                        <ul className="ml-2 list-disc">
                            {socialLinks.Music &&
                                socialLinks.Music.map((music) => (
                                    <li key={music._id} className="mb-2 mt-3 flex h-[55px] w-full items-center justify-between rounded-lg bg-purple-Light  px-3">
                                        <div className="flex items-center justify-center">
                                            {music.image && <Image src={music.image} width={25} height={25} alt={music} />}
                                            <span className="ml-2 font-normal">{music.linktitle}</span>

                                            <span className="ml-2 font-normal">{music.spotify_link && `${music.spotify_link}`}</span>
                                            <span className="ml-2 font-normal">{music.apple_link && `${music.apple_link}`}</span>
                                            <span className="ml-2 font-normal">{music.music_username && `${music.music_username}`}</span>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <button className="focus:outline-none" type="button" onClick={() => handleEditItem(music._id, 'music', music)}>
                                                <Image src={EditLink} width={20} height={20} alt="Edit" />
                                            </button>
                                            <button className="focus:outline-none" type="button" onClick={() => handleDeleteItem(music._id, 'music')}>
                                                <Image src={Delete} width={15} height={15} alt="Delete" />
                                            </button>
                                        </div>
                                    </li>
                                ))}
                        </ul>

                        <h3 className="ml-2 mt-4 text-xl font-semibold">Custom Info</h3>

                        <ul className="ml-2 list-disc">
                            {socialLinks.Custom_link &&
                                socialLinks.Custom_link.map((customlink) => (
                                    <li key={customlink._id} className="mb-2 mt-3 flex h-[55px] w-full items-center justify-between rounded-lg bg-purple-Light  px-3">
                                        <div className="flex items-center justify-center">
                                            {customlink.image && <Image src={customlink.image} width={25} height={25} alt={customlink} />}
                                            {/* <span className="ml-2 font-normal">{customlink.linktitle}</span> */}

                                            <span className="ml-2 font-normal">{customlink.file && `${customlink.file}`}</span>
                                            <span className="ml-2 font-normal">{customlink.custom_url && `${customlink.custom_url}`}</span>
                                            <span className="ml-2 font-normal">{customlink.label && `${customlink.label}`}</span>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <button className="focus:outline-none" type="button" onClick={() => handleEditItem(customlink._id, 'customlink', customlink)}>
                                                <Image src={EditLink} width={20} height={20} alt="Edit" />
                                            </button>
                                            <button className="focus:outline-none" type="button" onClick={() => handleDeleteItem(customlink._id, 'customlink')}>
                                                <Image src={Delete} width={15} height={15} alt="Delete" />
                                            </button>
                                        </div>
                                    </li>
                                ))}
                        </ul>

                        {/* Render other sections similarly */}
                    </div>
                )}
                <WelcomeMsg socialLinks={socialLinks} />
                <EditSocial
                    isOpen={isModalOpen}
                    onClose={closeModal}
                    SelectedSocialItem={SelectedSocialItem}
                    selectedSocial={selectedSocial}
                    SelectedSocialId={SelectedSocialId}
                    socialName={selectedSocial}
                ></EditSocial>

                {/* {!socialLinks && (
                    <div className="flex  flex-col items-center justify-center px-6 py-6 sm:px-12 sm:py-12">
                        <h2 className="text-xl font-bold sm:text-2xl">This profile doesn’t have any linked content</h2>
                        <p className="text-lightText mt-2 text-center text-black-themeBlack sm:mt-4">Add links to contact information, websites, payment methods, social networks and more.</p>
                    </div>
                )} */}
            </div>

            {/* Display todo items */}
            {/* {SocialItems.map((item) => (
                <div key={item.id} className="mx-4 flex justify-center">
                    <div className="mt-3 flex h-[55px] w-full items-center justify-between rounded-lg bg-gray-200 px-3">
                        <div className="flex items-center justify-center">
                            <Image src={item.image.path} width={25} height={25} alt={item.image.platform} />
                            <span className="ml-2 font-normal">{item.platform}</span>
                        </div>
                        <div className="flex items-center gap-4">
                            <button className="focus:outline-none" type="button" onClick={() => handleEditItem(item.id)}>
                                <Image src={EditLink} width={20} height={20} alt="Edit" />
                            </button>
                            <button className="focus:outline-none" type="button" onClick={() => handleDeleteItem(item.id)}>
                                <Image src={Delete} width={15} height={15} alt="Delete" />
                            </button>
                        </div>
                    </div>
                </div>
            ))} */}
        </div>
    );
};

export default SocialLinkLists;
export function WelcomeMsg({ socialLinks }) {
    return (
        <>
            {socialLinks.length === 0 ? (
                <div className="flex  flex-col items-center justify-center px-6 py-6 sm:px-12 sm:py-12">
                    <h2 className="text-xl font-bold sm:text-2xl">This profile doesn’t have any linked content</h2>
                    <p className="text-lightText mt-2 text-center text-black-themeBlack sm:mt-4">Add links to contact information, websites, payment methods, social networks and more.</p>
                </div>
            ) : null}
        </>
    );
}
