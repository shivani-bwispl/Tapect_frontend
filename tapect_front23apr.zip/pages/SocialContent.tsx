import axios from 'axios';
import React, { useState } from 'react';
import axiosInstance from '../services/api';
const SocialContent = ({ socialName, image, onClose, onNewItem, handleBackClick, isCustom }) => {
    let displayName = socialName;
    if (image) {
        displayName += ' username';
    }
    const [item, setItem] = useState('');
    const [link, setLink] = useState('');
    const [label, setLabel] = useState('');
    const [error, setError] = useState('');
    const handleNameChange = (event) => {
        setItem(event.target.value);
    };
    const handleLinkChange = (event) => {
        setLink(event.target.value);
    };
    const handleAction = async () => {
        if (!item || !link) {
            setError('Both fields are required');
            return;
        }
        if (!/^https?:\/\//i.test(link)) {
            setError('Link must start with http:// or https://');
            return;
        }
        try {
            const userId = localStorage.getItem('userId');
            if (!userId) {
                throw new Error('User ID not found in localStorage');
            }
           

            if (!socialName) {
                throw new Error('Social name is not provided');
            }
            // const isEditing = existingSocialLinks.some(entry => entry.socialMediaId === SelectedSocialId);

            const requestData = {
                userId,
                linktitle: link,
                platform: socialName,
                username: '',
                wechat_number: '',
                profile_link: '',
                channel_link: '',
                server_link: '',
                telegram_link: '',
                phone_number: '',
                contact_number: '',
                whatsapp_number: '',
                email_address: '',
                business_address: '',
                facetime: '',
                paypal_link: '',
                payment_username: '',
                spotify_link: '',
                apple_link: '',
                music_username: '',
                image: '',
                svg: '',
                url: '',
                custom_url: '',
                label: label,
                file: '',
                icon: '',
                businessId: '',
                socialMediaId: '',
                contactId: '',
                paymentId: '',
                musicId:'',
                customlinkId: '',
            };

            // Map of platform names to corresponding field names
            const platformFields = {
                // Add mappings for all supported platforms
                instagram: ['username'],
                linkedin: ['profile_link'],
                facebook: ['profile_link'],
                message: ['username'],
                email: ['username'],
                website: ['url'],
                paypal: ['paypal_link'],
                googlemap: ['url'],
                facetime: ['facetime'],
                whatsapp: ['whatsapp_number'],
                googlepay: ['payment_username'],
                youtube: ['channel_link'],
                twitter: ['username'],
                wechat: ['wechat_number'],
                threads: ['profile_link'],
                twitch: ['channel_link'],
                tiktok: ['username'],
                snapchat: ['username'],
                pinterest: ['username'],
                discord: ['server_link'],
                telegram: ['telegram_link'],
                clubhouse: ['username'],
                calendly: ['url'],
                reviews: ['contact_number'],
                etsy: ['username'],
                applestore: ['username'],
                chilipiper: ['url'],
                microsoftbooking: ['username'],
                booksy: ['username'],
                square: ['username'],
                zillow: ['username'],
                cashapp: ['payment_username'],
                venmo: ['payment_username'],
                zelle: ['payment_username'],
                spotify: ['spotify_link'],
                applemusic: ['apple_link'],
                soundcloud: ['music_username'],
                podcasts: ['music_username'],
                poshmark: ['username'],
                mediakits: ['username'],
                opensea: ['username'],
                hoobe: ['username'],
                linktree: ['username'],
                file: ['label'],
                customlink: ['custom_url'],
                // Add mappings for other platforms as needed
            };

            // Set relevant fields based on platform name
            const platformName = socialName.toLowerCase();
            if (platformFields.hasOwnProperty(platformName)) {
                const fields = platformFields[platformName];
                fields.forEach((field) => {
                    requestData[field] = item; // Assuming todoName contains the value for the field
                });
            }
            // const config = {
            //     headers: {
            //         'X-Selected-Social-Id': SelectedSocialId,
            //     },
            // };

            // const response = await axiosInstance.post('/SocialLinks/', requestData);
            const response = await axiosInstance.post(`/SocialLinks/`, requestData);

            // window.location.reload(); // Refresh the page without loading

            // console.log(response.data,"responsedata"); // Log the response from the server
            console.log('Data updated successfully:', response.data);

            // Reset fields and errors
            setLink('');
            setLabel('');
            setItem('');
            onClose(false); // Close the dialog
        } catch (error) {
            console.error('Error:', error.message);
            // Handle error if needed
        }
        // try {
        //     const userId = localStorage.getItem('userId');
        //     if (!userId) {
        //         throw new Error('User ID not found in localStorage');
        //     }
        //     const requestData = {
        //         userId,
        //         linktitle: link,
        //         platform: socialName,
        //         username: '',
        //         wechat_number: '',
        //         profile_link: '',
        //         channel_link: '',
        //         server_link: '',
        //         telegram_link: '',
        //         socialMediaId: '',
        //         phone_number: '',
        //         contact_number: '',
        //         whatsapp_number: '',
        //         email_address: '',
        //         business_address: '',
        //         facetime: '',
        //         paypal_link: '',
        //         payment_username: '',
        //         spotify_link: '',
        //         apple_link: '',
        //         music_username: '',
        //         image: '',
        //         svg: '',
        //         url: '',
        //         custom_url: '',
        //         label: label,
        //         icon: '',
        //         businessId: '',
        //         contactId: '',
        //         paymentId: '',
        //         musicId: '',
        //         customlinkId: '',
        //     };
        //     // Map of platform names to corresponding field names
        //     const platformFields = {
        //         // Add mappings for all supported platforms
        //         instagram: ['username'],
        //         linkedin: ['profile_link'],
        //         facebook: ['profile_link'],
        //         message: ['username'],
        //         email: ['username'],
        //         website: ['url'],
        //         paypal: ['paypal_link'],
        //         googlemap: ['url'],
        //         facetime: ['facetime'],
        //         whatsapp: ['whatsapp_number'],
        //         googlepay: ['payment_username'],
        //         youtube: ['channel_link'],
        //         twitter: ['username'],
        //         wechat: ['wechat_number'],
        //         threads: ['profile_link'],
        //         twitch: ['channel_link'],
        //         tiktok: ['username'],
        //         snapchat: ['username'],
        //         pinterest: ['username'],
        //         discord: ['server_link'],
        //         telegram: ['telegram_link'],
        //         clubhouse: ['username'],
        //         calendly: ['url'],
        //         reviews: ['contact_number'],
        //         etsy: ['username'],
        //         applestore: ['username'],
        //         chilipiper: ['url'],
        //         microsoftbooking: ['username'],
        //         booksy: ['username'],
        //         square: ['username'],
        //         zillow: ['username'],
        //         cashapp: ['payment_username'],
        //         venmo: ['payment_username'],
        //         zelle: ['payment_username'],
        //         spotify: ['spotify_link'],
        //         applemusic: ['apple_link'],
        //         soundcloud: ['music_username'],
        //         podcasts: ['music_username'],
        //         poshmark: ['username'],
        //         mediakits: ['username'],
        //         opensea: ['username'],
        //         hoobe: ['username'],
        //         linktree: ['username'],
        //         file: ['label'],
        //         customlink: ['custom_url'],
        //         // Add mappings for other platforms as needed
        //     };
        //     // Set relevant fields based on platform name
        //     if (platformFields.hasOwnProperty(socialName.toLowerCase())) {
        //         const fields = platformFields[socialName.toLowerCase()];
        //         fields.forEach((field) => {
        //             requestData[field] = item; // Assuming item contains the value for the field
        //         });
        //     }
        //     const response = await axiosInstance.post('/SocialLinks/', requestData);
        //     // window.location.reload(); // Refresh the page without loading
        //     console.log(response.data, 'responsesocial'); // Log the response from the server
        //     // window.location.reload();
        //     onNewItem(item, image, link);
        //     // Reset fields and errors
        //     setItem('');
        //     setLink('');
        //     setLabel('');
        //     setError('');
        //     handleBackClick();
        // } catch (error) {
        //     console.error('Error:', error.message);
        //     // Handle error if needed
        // }
    };
    return (
        <div className="p-6">
            <span className="text-[24px] tracking-wide"> Social Link</span>
            <div className="m-4 flex items-center">
                <div className="flex items-center space-x-2">
                    <img src={image.path} alt={displayName} className="h-12 w-12" />
                    <h1 className="text-lg font-medium capitalize">{image.platform}</h1>
                </div>
            </div>
            {isCustom === 'customlink' ? (
                <div>
                    <div className="m-4">
                        <h2 className=" pb-2 text-sm font-normal">Link Title</h2>
                        <input
                            name="LinkTitle"
                            type="text"
                            placeholder="Link title"
                            className="form-input h-[45px]"
                            value={link}
                            // pattern="^(https?:\/\/).*"
                            // title="Website must start with http:// or https://"
                            required
                        />
                    </div>
                    <div className="m-4">
                        <h2 className=" pb-2  text-sm font-normal">Link</h2>
                        <input type="text" placeholder="Link" className=" form-input h-[45px]" value={item} />
                    </div>
                </div>
            ) : isCustom === 'file' ? (
                <div>
                    <div className="m-4">
                        <h2 className=" pb-2 text-sm font-normal">File Title*</h2>
                        <input
                            type="text"
                            placeholder="File title"
                            className="form-input h-[45px]"
                            value={label}
                            onChange={(event) => setLabel(event.target.value)} // Add onChange handler to update the 'label' state
                        />
                    </div>
                    <div className="m-4">
                        <h2 className=" pb-2 text-sm font-normal">File*</h2>
                        <label htmlFor="file-upload" className="btn btn-primary mr-5 h-[40px] cursor-pointer text-base">
                            Upload File
                            <span className="text-xs">(Max file size 1MB)</span>
                        </label>
                        <input
                            id="file-upload"
                            type="file"
                            className="hidden"
                            accept=".pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx, image/*"
                        // onChange={(e) => handleFileUpload(e.target.files)}
                        />
                    </div>
                </div>
            ) : (
                <div>
                    <div className="m-4 space-y-2">
                        <h2 className="pb-2 text-sm font-normal sm:text-base">{displayName}</h2>
                        <input type="text" placeholder={displayName} onChange={handleNameChange} value={item} className="form-input h-[45px] w-full" required />
                        <h2 className="pb-2 text-sm font-normal sm:text-base">Link</h2>
                        <input type="text" placeholder="Link" className="form-input h-[45px] w-full" value={link} onChange={handleLinkChange} required />
                    </div>
                    {error && <p className="text-red-500">{error}</p>}
                </div>
            )}
            <div className="flex justify-end">
                <button type="button" className="mr-10 underline underline-offset-4" onClick={() => onClose(false)}>
                    Cancel
                </button>
                <button type="button" className="btn btn-primary mx-4 h-[40px] w-[130px] transition duration-300 ease-in-out" onClick={handleAction}>
                    Add Link
                </button>
            </div>
        </div>
    );
};
export default SocialContent;
