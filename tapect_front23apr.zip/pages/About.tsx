import router from 'next/router';
import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import updateUserProfile from './controller/updateUserProfile'; // Import the updateUserProfile function
import axios from 'axios';
import toastUtils from '../services/toastUtils';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content'; // Import the toast utility service
import axiosInstance from '../services/api'; // Import axiosInstance from api.js

const About = ({ formData, handleInputChange }) => {
    const {
        register,
        handleSubmit,
        control,
        setValue,

        formState: { errors },
    } = useForm();
    const [userProfiles, setUserProfiles] = useState([FormData]);
    const MySwal = withReactContent(Swal);

    const showToast = () => {
        MySwal.fire({
            title: 'Profile updated successfully',
            toast: true,
            position: 'top',
            showConfirmButton: false,
            timer: 3000,
            background: '#4CAF50',
            showCloseButton: true,
        });
    };

    const handleAboutFormUpdate = async (data: any) => {
        try {
            const userId = localStorage.getItem('userId');
            if (!userId) {
                throw new Error('User ID not found in localStorage');
            }

            // Include userId in the data object
            data.userId = userId;
            const response = await axiosInstance.post('/profileUpdate/', data);
            console.log(response.data); // Log the response from the server
            router.replace(router.asPath);

            // Display toast on successful form submission
            showToast();
            // Optionally, perform any additional actions after successful update
            toastUtils.success('Profile updated successfully'); // Display success message
        } catch (error) {
            console.error('Error updating user profile:', errors.message);
            // Optionally, handle the error and display an error message to the user
            toastUtils.error('Failed to update profile'); // Display error message
        }
        console.log('Form Submitted!', data);
    };

    useEffect(() => {
        const fetchUserProfile = async () => {
            try {
                const userId = localStorage.getItem('userId');
                if (!userId) {
                    throw new Error('User ID not found in localStorage');
                }
                const response = await axios.get(`http://localhost:3001/api/profileUpdate/${userId}`);
                const userProfileData = response.data;
                Object.keys(userProfileData).forEach((key) => {
                    setValue(key, userProfileData[key]);
                });
                setUserProfiles([userProfileData]); // Assuming response.data is an object
            } catch (error) {
                console.error('Error fetching user profile:', errors.message);
                setUserProfiles([]); // Reset user profile state to an empty array or set a default value
            }
        };

        fetchUserProfile(); // Call fetchUserProfile when the component mounts
    }, []);

    return (
        <>
            <div className="mb-5">
                <div id="forms_grid ">
                    <div className=" mt-5  px-3 ">
                        <span className=" text-lg font-bold">Profile Details</span>
                        {/* form  */}
                        <form className="my-2 space-y-5 py-2" onSubmit={handleSubmit(handleAboutFormUpdate)} noValidate>
                            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                                <div>
                                    <label htmlFor="first_name" className="text-[13px]">
                                        First Name
                                    </label>
                                    <input
                                        id="first_name"
                                        type="text"
                                        name="first_name"
                                        className="form-input"
                                        {...register('first_name', {
                                            required: 'First name is required',
                                            maxLength: { value: 100, message: 'First name cannot exceed 100 characters' },
                                        })}
                                        onChange={handleInputChange}
                                        defaultValue={userProfiles ? userProfiles.first_name : ''}
                                        placeholder=" Enter First name"
                                    />
                                    {errors.first_name && <p className="text-red-500">{errors.first_name.message}</p>}
                                </div>
                                <div>
                                    <label htmlFor="last_name" className="text-[13px]">
                                        Last Name
                                    </label>
                                    <input
                                        id="last_name"
                                        type="text"
                                        name="last_name"
                                        className="form-input"
                                        {...register('last_name', {
                                            required: 'Last name is required',
                                            maxLength: { value: 100, message: 'Last name cannot exceed 100 characters' },
                                        })}
                                        onChange={handleInputChange}
                                        defaultValue={userProfiles ? userProfiles.last_name : ''}
                                        placeholder=" Enter last name"
                                    />
                                    {errors.last_name && <p className="text-red-500">{errors.last_name.message}</p>}
                                </div>
                                <div>
                                    <label htmlFor="job_title" className="text-[13px]">
                                        Job Title
                                    </label>
                                    <input
                                        id="job_title"
                                        type="text"
                                        name="job_title"
                                        className="form-input"
                                        {...register('job_title', {
                                            required: 'Job title is required',
                                            maxLength: { value: 100, message: 'Job title cannot exceed 100 characters' },
                                        })}
                                        onChange={handleInputChange}
                                        defaultValue={userProfiles ? userProfiles.job_title : ''}
                                        placeholder=" Enter job title"
                                    />
                                    {errors.job_title && <p className="text-red-500">{errors.job_title.message}</p>}
                                </div>
                                <div>
                                    <label htmlFor="organization_name" className="text-[13px]">
                                        Company
                                    </label>
                                    <input
                                        id="organization_name"
                                        type="text"
                                        name="organization_name"
                                        className="form-input"
                                        {...register('organization_name', {
                                            required: 'Company name is required',
                                            maxLength: { value: 100, message: 'Company name cannot exceed 100 characters' },
                                        })}
                                        onChange={handleInputChange}
                                        defaultValue={userProfiles ? userProfiles.organization_name : ''}
                                        placeholder=" Enter organization name"
                                    />
                                    {errors.organization_name && <p className="text-red-500">{errors.organization_name.message}</p>}
                                </div>
                                <div>
                                    <label htmlFor="profile_email" className="text-[13px]">
                                        Email
                                    </label>
                                    <input
                                        id="profile_email"
                                        type="email"
                                        className="form-input"
                                        name="profile_email"
                                        {...register('profile_email', {
                                            required: 'Email is required',
                                            pattern: {
                                                value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
                                                message: 'Please enter a valid email address',
                                            },
                                        })}
                                        onChange={handleInputChange}
                                        defaultValue={userProfiles ? userProfiles.profile_name : ''}
                                        placeholder=" Enter email address"
                                    />
                                    {errors.profile_email && <p className="text-red-500">{errors.profile_email.message}</p>}
                                </div>
                                <div>
                                    <label htmlFor="phone_number" className="text-[13px]">
                                        Phone Number
                                    </label>
                                    <input
                                        id="phone_number"
                                        type="tel"
                                        className="form-input"
                                        name="phone_number"
                                        {...register('phone_number', {
                                            required: 'Phone number is required',
                                            pattern: {
                                                value: /^[0-9]{10}$/,
                                                message: 'Phone number must be 10 digits and contain only numbers',
                                            },
                                        })}
                                        onChange={handleInputChange}
                                        defaultValue={userProfiles ? userProfiles.phone_number : ''}
                                        placeholder=" Enter  phone number"
                                    />
                                    {errors.phone_number && <p className="text-red-500">{errors.phone_number.message}</p>}
                                </div>
                            </div>

                            {/* Notes  */}
                            <div>
                                <label className="text-[13px]"> Bio</label>
                                <textarea
                                    className=" h-[80px] w-full resize-none whitespace-normal border  border-white-light p-2 focus:outline-0"
                                    name="note"
                                    {...register('note', { required: false, maxLength: 250 })}
                                    onChange={handleInputChange}
                                    defaultValue={userProfiles ? userProfiles.notes : ''}
                                    placeholder="Notes"
                                ></textarea>

                                <p className="text-right text-primary">{250 - formData.note.length} characters remaining</p>
                            </div>

                            <div className="mt-4 flex justify-end">
                                <button type="button" className="mr-10 underline underline-offset-4">
                                    Cancel
                                </button>

                                <button type="submit" className="btn btn-primary mr-5 h-[40px] w-[130px]">
                                    Update
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </>
    );
};

export default About;
