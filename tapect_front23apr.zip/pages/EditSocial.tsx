import React, { useEffect, useState } from 'react';
import { Dialog, Transition } from '@headlessui/react';
import { Fragment } from 'react';
import IconX from '@/components/Icon/IconX';
import axios from 'axios';
import axiosInstance from '@/services/api';

const EditSocial = ({ isOpen, onClose, SelectedSocialItem, SelectedSocialId, selectedSocial }) => {
    console.log(SelectedSocialItem, 'SelectedSocialItem');
    console.log(selectedSocial, 'selectedSocial');
    // console.log(SelectedSocialItem.platform, "socialName")
    const socialName = SelectedSocialItem.platform;
    console.log(socialName, 'socialName');

    // const [item, setItem] = useState(SelectedSocialItem.username || '');

    const [linkTitle, setLinkTitle] = useState(SelectedSocialItem.linktitle || '');
    const [label, setLabel] = useState('');
    const [file, setFile] = useState(null);
    const [fileError, setFileError] = useState('');

    // Validation function for file upload
    const validateFile = () => {
        if (!file) {
            setFileError('Please upload a file');
            return false;
        }
        if (file.size > 1024 * 1024) {
            setFileError('File size exceeds the limit (1MB)');
            return false;
        }
        if (!label.trim()) {
            setFileError('File title cannot be empty');
            return false;
        }
        // Additional validation logic can be added here if needed
        return true;
    };

    const [item, setItem] = useState(
        SelectedSocialItem.username ||
            SelectedSocialItem.wechat_number ||
            SelectedSocialItem.profile_link ||
            SelectedSocialItem.channel_link ||
            SelectedSocialItem.server_link ||
            SelectedSocialItem.telegram_link ||
            SelectedSocialItem.phone_number ||
            SelectedSocialItem.contact_number ||
            SelectedSocialItem.whatsapp_number ||
            SelectedSocialItem.email_address ||
            SelectedSocialItem.business_address ||
            SelectedSocialItem.facetime ||
            SelectedSocialItem.paypal_link ||
            SelectedSocialItem.payment_username ||
            SelectedSocialItem.spotify_link ||
            SelectedSocialItem.apple_link ||
            SelectedSocialItem.music_username ||
            SelectedSocialItem.custom_url ||
            SelectedSocialItem.label ||
            SelectedSocialItem.file ||
            ''
    );

    useEffect(() => {
        setItem(
            SelectedSocialItem.username ||
                SelectedSocialItem.wechat_number ||
                SelectedSocialItem.profile_link ||
                SelectedSocialItem.channel_link ||
                SelectedSocialItem.server_link ||
                SelectedSocialItem.telegram_link ||
                SelectedSocialItem.phone_number ||
                SelectedSocialItem.contact_number ||
                SelectedSocialItem.whatsapp_number ||
                SelectedSocialItem.email_address ||
                SelectedSocialItem.business_address ||
                SelectedSocialItem.facetime ||
                SelectedSocialItem.paypal_link ||
                SelectedSocialItem.payment_username ||
                SelectedSocialItem.spotify_link ||
                SelectedSocialItem.apple_link ||
                SelectedSocialItem.music_username ||
                SelectedSocialItem.custom_url ||
                SelectedSocialItem.label ||
                SelectedSocialItem.file ||
                ''
        );

        setLinkTitle(SelectedSocialItem.linktitle || '');
    }, [SelectedSocialItem]);

    // const handleUpdate = async () => {
    //     try {
    //         const userId = localStorage.getItem('userId');
    //         if (!userId) {
    //             throw new Error('User ID not found in localStorage');
    //         }
    //         if (!SelectedSocialId) {
    //             throw new Error('SelectedSocialId is not provided');
    //         }
    //         console.log(SelectedSocialId, 'SelectedSocialIdin');

    //         if (!socialName) {
    //             throw new Error('Social name is not provided');
    //         }
    //         if (!validateFile()) {
    //             return; // Stop execution if validation fails
    //         }

    //         try {
    //             // Your existing update logic here...

    //             // Reset fields and errors
    //             setLabel('');
    //             setFile(null);
    //             setFileError('');
    //             onClose(false); // Close the dialog
    //         } catch (error) {
    //             console.error('Error:', error.message);
    //             // Handle error if needed
    //         }

    //         // const isEditing = existingSocialLinks.some(entry => entry.socialMediaId === SelectedSocialId);

    //         const requestData = {
    //             userId,
    //             linktitle: linkTitle,
    //             platform: socialName,
    //             username: '',
    //             wechat_number: '',
    //             profile_link: '',
    //             channel_link: '',
    //             server_link: '',
    //             telegram_link: '',
    //             phone_number: '',
    //             contact_number: '',
    //             whatsapp_number: '',
    //             email_address: '',
    //             business_address: '',
    //             facetime: '',
    //             paypal_link: '',
    //             payment_username: '',
    //             spotify_link: '',
    //             apple_link: '',
    //             music_username: '',
    //             image: '',
    //             svg: '',
    //             url: '',
    //             custom_url: '',
    //             label: label,
    //             icon: '',
    //             businessId: '',
    //             socialMediaId: SelectedSocialId,
    //             contactId: SelectedSocialId,
    //             paymentId: SelectedSocialId,
    //             musicId: SelectedSocialId,
    //             customlinkId: SelectedSocialId,
    //         };

    //         // Map of platform names to corresponding field names
    //         const platformFields = {
    //             // Add mappings for all supported platforms
    //             instagram: ['username'],
    //             linkedin: ['profile_link'],
    //             facebook: ['profile_link'],
    //             message: ['username'],
    //             email: ['username'],
    //             website: ['url'],
    //             paypal: ['paypal_link'],
    //             googlemap: ['url'],
    //             facetime: ['facetime'],
    //             whatsapp: ['whatsapp_number'],
    //             googlepay: ['payment_username'],
    //             youtube: ['channel_link'],
    //             twitter: ['username'],
    //             wechat: ['wechat_number'],
    //             threads: ['profile_link'],
    //             twitch: ['channel_link'],
    //             tiktok: ['username'],
    //             snapchat: ['username'],
    //             pinterest: ['username'],
    //             discord: ['server_link'],
    //             telegram: ['telegram_link'],
    //             clubhouse: ['username'],
    //             calendly: ['url'],
    //             reviews: ['contact_number'],
    //             etsy: ['username'],
    //             applestore: ['username'],
    //             chilipiper: ['url'],
    //             microsoftbooking: ['username'],
    //             booksy: ['username'],
    //             square: ['username'],
    //             zillow: ['username'],
    //             cashapp: ['payment_username'],
    //             venmo: ['payment_username'],
    //             zelle: ['payment_username'],
    //             spotify: ['spotify_link'],
    //             applemusic: ['apple_link'],
    //             soundcloud: ['music_username'],
    //             podcasts: ['music_username'],
    //             poshmark: ['username'],
    //             mediakits: ['username'],
    //             opensea: ['username'],
    //             hoobe: ['username'],
    //             linktree: ['username'],
    //             file: ['file'],
    //             customlink: ['customlink'],
    //             // Add mappings for other platforms as needed
    //         };

    //         // Set relevant fields based on platform name
    //         const platformName = socialName.toLowerCase();
    //         if (platformFields.hasOwnProperty(platformName)) {
    //             const fields = platformFields[platformName];
    //             fields.forEach((field) => {
    //                 requestData[field] = item; // Assuming todoName contains the value for the field
    //             });
    //         }
    //         const config = {
    //             headers: {
    //                 'X-Selected-Social-Id': SelectedSocialId,
    //             },
    //         };

    //         // const response = await axiosInstance.post('/SocialLinks/', requestData);
    //         const response = await axiosInstance.post(`/SocialLinks/`, requestData, config);

    //         // window.location.reload(); // Refresh the page without loading

    //         console.log(response.data, 'responsedata'); // Log the response from the server

    //         // Reset fields and errors
    //         setLinkTitle('');
    //         setItem('');
    //         onClose(false); // Close the dialog
    //     } catch (error) {
    //         console.error('Error:', error.message);
    //         // Handle error if needed
    //     }
    // };
    const handleUpdate = async () => {
        try {
            const userId = localStorage.getItem('userId');
            if (!userId) {
                throw new Error('User ID not found in localStorage');
            }
            if (!SelectedSocialId) {
                throw new Error('SelectedSocialId is not provided');
            }

            if (!socialName) {
                throw new Error('Social name is not provided');
            }
            // const isEditing = existingSocialLinks.some(entry => entry.socialMediaId === SelectedSocialId);

            const requestData = {
                userId,
                linktitle: linkTitle,
                platform: socialName,
                username: '',
                wechat_number: '',
                profile_link: '',
                channel_link: '',
                server_link: '',
                telegram_link: '',
                phone_number: '',
                contact_number: '',
                whatsapp_number: '',
                email_address: '',
                business_address: '',
                facetime: '',
                paypal_link: '',
                payment_username: '',
                spotify_link: '',
                apple_link: '',
                music_username: '',
                image: '',
                svg: '',
                url: '',
                custom_url: '',
                label: label,
                file: '',
                icon: '',
                businessId: '',
                socialMediaId: SelectedSocialId,
                contactId: SelectedSocialId,
                paymentId: SelectedSocialId,
                musicId: SelectedSocialId,
                customlinkId: SelectedSocialId,
            };

            // Map of platform names to corresponding field names
            const platformFields = {
                // Add mappings for all supported platforms
                instagram: ['username'],
                linkedin: ['profile_link'],
                facebook: ['profile_link'],
                message: ['username'],
                email: ['username'],
                website: ['url'],
                paypal: ['paypal_link'],
                googlemap: ['url'],
                facetime: ['facetime'],
                whatsapp: ['whatsapp_number'],
                googlepay: ['payment_username'],
                youtube: ['channel_link'],
                twitter: ['username'],
                wechat: ['wechat_number'],
                threads: ['profile_link'],
                twitch: ['channel_link'],
                tiktok: ['username'],
                snapchat: ['username'],
                pinterest: ['username'],
                discord: ['server_link'],
                telegram: ['telegram_link'],
                clubhouse: ['username'],
                calendly: ['url'],
                reviews: ['contact_number'],
                etsy: ['username'],
                applestore: ['username'],
                chilipiper: ['url'],
                microsoftbooking: ['username'],
                booksy: ['username'],
                square: ['username'],
                zillow: ['username'],
                cashapp: ['payment_username'],
                venmo: ['payment_username'],
                zelle: ['payment_username'],
                spotify: ['spotify_link'],
                applemusic: ['apple_link'],
                soundcloud: ['music_username'],
                podcasts: ['music_username'],
                poshmark: ['username'],
                mediakits: ['username'],
                opensea: ['username'],
                hoobe: ['username'],
                linktree: ['username'],
                file: ['label'],
                customlink: ['custom_url'],
                // Add mappings for other platforms as needed
            };

            // Set relevant fields based on platform name
            const platformName = socialName.toLowerCase();
            if (platformFields.hasOwnProperty(platformName)) {
                const fields = platformFields[platformName];
                fields.forEach((field) => {
                    requestData[field] = item; // Assuming todoName contains the value for the field
                });
            }
            const config = {
                headers: {
                    'X-Selected-Social-Id': SelectedSocialId,
                },
            };

            // const response = await axiosInstance.post('/SocialLinks/', requestData);
            const response = await axiosInstance.post(`/SocialLinks/`, requestData, config);

            // window.location.reload(); // Refresh the page without loading

            // console.log(response.data,"responsedata"); // Log the response from the server
            console.log('Data updated successfully:', response.data);

            // Reset fields and errors
            setLinkTitle('');
            setLabel('');
            setItem('');
            onClose(false); // Close the dialog
        } catch (error) {
            console.error('Error:', error.message);
            // Handle error if needed
        }
    };

    return (
        <div style={{ display: isOpen ? 'block' : 'none' }}>
            <Transition appear show={isOpen} as={Fragment}>
                <Dialog as="div" open={isOpen} onClose={onClose}>
                    <Transition.Child as={Fragment} enter="ease-out duration-300" enterFrom="opacity-0" enterTo="opacity-100" leave="ease-in duration-200" leaveFrom="opacity-100" leaveTo="opacity-0">
                        <div className="fixed inset-0" />
                    </Transition.Child>
                    <div className="fixed inset-0 z-[999] bg-[black]/60">
                        <div className="flex min-h-screen items-start justify-center px-5">
                            <Transition.Child
                                as={Fragment}
                                enter="ease-out duration-300"
                                enterFrom="opacity-0 scale-95"
                                enterTo="opacity-100 scale-100"
                                leave="ease-in duration-200"
                                leaveFrom="opacity-100 scale-100"
                                leaveTo="opacity-0 scale-95"
                            >
                                <Dialog.Panel className="panel my-auto h-[70vh] w-[50vw] max-w-5xl overflow-y-auto overflow-x-hidden rounded-[20px] border-0 bg-white p-0 px-10 py-10 text-black dark:text-white-dark">
                                    <div className="flex items-center justify-between dark:bg-[#121c2c]">
                                        <div>
                                            <span className="text-[24px] tracking-wide"> Social Link</span>
                                        </div>
                                        <button
                                            onClick={() => {
                                                onClose(false);
                                            }}
                                            type="button"
                                            className="text-white-dark hover:text-dark"
                                        >
                                            <IconX className="mt-2 w-12 pl-7" />
                                        </button>
                                    </div>
                                    <div className="p-3">
                                        <div className="m-4 flex items-center">
                                            <div className="flex items-center space-x-3">
                                                <img src={SelectedSocialItem.image} alt="instagram" className="h-12 w-12" />
                                                <h1 className="text-lg font-medium capitalize">{SelectedSocialItem.platform}</h1>
                                            </div>
                                        </div>
                                        {socialName === 'file' ? (
                                            <div>
                                                <div className="m-4">
                                                    <h2 className=" pb-2 text-sm font-normal">File Title*</h2>
                                                    <input
                                                        type="text"
                                                        placeholder="File title"
                                                        className="form-input h-[45px]"
                                                        value={item}
                                                        onChange={(event) => setItem(event.target.value)} // Add onChange handler to update the 'label' state
                                                    />
                                                </div>
                                                <div className="m-4">
                                                    <h2 className=" pb-2 text-sm font-normal">File*</h2>
                                                    <label htmlFor="file-upload" className="btn btn-primary mr-5 h-[40px] cursor-pointer text-base">
                                                        Upload File
                                                        <span className="text-xs">(Max file size 1MB)</span>
                                                    </label>
                                                    <input
                                                        id="file-upload"
                                                        type="file"
                                                        className="hidden"
                                                        accept=".pdf, .doc, .docx, .xls, .xlsx, .ppt, .pptx, image/*"
                                                        onChange={(e) => setFile(e.target.files[0])}
                                                    />
                                                    {fileError && <p className="text-red-500">{fileError}</p>}
                                                </div>
                                            </div>
                                        ) : (
                                            <div>
                                                <div className="m-4 space-y-2">
                                                    <h2 className="pb-2 text-sm font-normal sm:text-base">{SelectedSocialItem.platform}</h2>
                                                    <input
                                                        type="text"
                                                        placeholder="INPUT"
                                                        className="form-input h-[45px] w-full"
                                                        required
                                                        value={item} // Displaying the 'platform' property
                                                        onChange={(e) => setItem(e.target.value)}
                                                    />

                                                    <h2 className="pb-2 text-sm font-normal sm:text-base">Link</h2>
                                                    <input
                                                        type="text"
                                                        placeholder="Link"
                                                        className="form-input h-[45px] w-full"
                                                        required
                                                        value={linkTitle}
                                                        onChange={(e) => setLinkTitle(e.target.value)}
                                                    />
                                                </div>
                                            </div>
                                        )}

                                        <div className=" mt-16 flex justify-end gap-7">
                                            <button type="button" className="underline underline-offset-4" onClick={() => onClose(false)}>
                                                Cancel
                                            </button>
                                            <button type="button" className="btn btn-primary h-[40px] w-[130px] transition duration-300 ease-in-out" onClick={handleUpdate}>
                                                Update
                                            </button>
                                        </div>
                                    </div>
                                </Dialog.Panel>
                            </Transition.Child>
                        </div>
                    </div>
                </Dialog>
            </Transition>
        </div>
    );
};

export default EditSocial;
