import axios from 'axios';

// Define your base URL
export const BASE_IMg_URL = 'http://localhost:3001/';

// Create an instance of Axios with the base URL set
const axiosInstanceimg = axios.create({
    baseURL: BASE_IMg_URL,
});

export default axiosInstanceimg;
